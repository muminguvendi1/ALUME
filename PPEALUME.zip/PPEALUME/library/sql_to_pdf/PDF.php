<?php

$bddname = 'alume';
$hostname = 'localhost';
$username = 'root';
$password = '';
$db = mysqli_connect($hostname, $username, $password, $bddname);

// Appel de la librairie FPDF
require("fpdf.php");

class PDF extends FPDF {
    // Header
    function Header() {


        // Arial gras 15
        $this->SetFont('Arial', 'B', 10);
        // Calcul de la largeur du titre et positionnement
        // Couleurs du cadre, du fond et du texte
        $this->SetDrawColor(98, 98, 98);
        $this->SetFillColor(255, 255, 255);
        $this->SetTextColor(227, 59, 0);
        // Logo
        // Saut de ligne
        $this->Ln(20);
        
        $position_entete = 102;

            $this->SetDrawColor(183); // Couleur du fond
    $this->SetFillColor(221); // Couleur des filets
    $this->SetTextColor(0); // Couleur du texte
    $this->SetY($position_entete);
    $this->SetX(8);
    $this->Cell(109 ,8,utf8_decode('Désignation'),1,0,'L', 1);
    $this->SetX(117);
    $this->Cell(13 ,8,utf8_decode('Qte'),1,0,'C', 1);
    $this->SetX(130);
    $this->Cell(25 ,8,utf8_decode('Net HT'),1,0,'C', 1);
    $this->SetX(155);
    $this->Cell(19 ,8,utf8_decode('TVA (%)'),1,0,'C', 1);
    $this->SetX(174);
    $this->Cell(26 ,8,utf8_decode('Prix TTC (eu)'),1,0,'C', 1);

    $this->Ln(); // Retour à la ligne
    
    }

    // Footer
    function Footer() {
        // Positionnement à 1,5 cm du bas
        $this->SetY(-15);
        // Adresse
        $this->Cell(196,5,utf8_decode('Contact : 10 rue Pegolèse Paris 75016 | +3314 5874 695 | serviceclient@alume.pro'),0,1,'C');
    }

}

$id_commande = $this->_getParam('id_commande', 0);

/* * *****************************************  Select : Détails de la facture  ********************************************************************************** */
$req3 = "SELECT c.id_commande, f.date_facture, f.id_facture, c.id_utilisateur, f.date_reglement, c.date_liv_souhaite FROM facture f, commande c WHERE c.id_commande = f.id_facture and f.id_facture = ". (int) $id_commande;
$rep3 = mysqli_query($db, $req3);
$row3 = mysqli_fetch_array($rep3);
/* * ************************************************************************************************************************************************************** */
/* * *****************************************  Select : Contenu des cases  ********************************************************************************** */
$position_detail = 110; // Position à 8mm de l'entête
$req2 = "SELECT p.designation_produit as libelle, l.quantite_commande as qte, p.prix_produit as netHT, p.tva_produit as tva, (p.prixTTC * l.quantite_commande) as prixTTC from lignecommande l, produit p where l.id_produit = p.id_produit and l.id_commande = ". (int) $id_commande;
$rep2 = mysqli_query($db, $req2);
/* * *************************************************************************************************************************************************************** */
/* * *****************************************  Select : Total commande  ********************************************************************************** */
$req4 = "select truncate(sum(prixTTC * quantite_commande),2) - truncate(sum(prixTTC * quantite_commande)/1.20,2) as total_tva, truncate(sum(prixTTC * quantite_commande)/1.20,2) as total_ht, truncate(sum(prixTTC * quantite_commande),2) as total_ttc from produit p, lignecommande lc where lc.id_produit = p.id_produit and lc.id_commande = ". (int) $id_commande;

$rep4 = mysqli_query($db, $req4);
$row4 = mysqli_fetch_array($rep4);
/* * ************************************************************************************************************************************************************** */

// Activation de la classe
$pdf = new PDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->Image('images\alume.jpg', 6, 2, 70);
$pdf->SetFont('Helvetica', '', 11);
$pdf->SetTextColor(0);

/* * *****************************************  Case TOTAL COMMANDE  ********************************************************************************** */
$pdf->SetXY(125, 230);
$pdf->Cell(40 ,10,utf8_decode('Total a payer du : '). $row3['date_facture'], "", "", "C");
$pdf->SetXY(120, 240);
$pdf->Cell(60, 20, '', 1);
$pdf->Text(123, 246, 'Total TVA : ' . $row4['total_tva'].' eu');
$pdf->Text(123, 252, 'Total HT   : ' . $row4['total_ht'].' eu');
$pdf->Text(123, 258, 'Total TTC : ' . $row4['total_ttc'].' eu');


$pdf->Text(140,20,utf8_decode('Facture N° : ' . $id_commande));

/* * *******************Coordonnées d'alume****************************** */
$pdf->Text(20,58,utf8_decode('Adresse : 10 rue Pegolèse'));
$pdf->Text(20,64,utf8_decode('Ville : 75016'));
$pdf->Text(20,70,utf8_decode('Tel : +3314 5874 695'));
$pdf->Text(20,76,utf8_decode('Mail : serviceclient@alume.pro'));
$pdf->Text(20,82,utf8_decode('N° siret : 404 833 048 00022'));
/* * ********************************************************************** */
/* * *******************Détails de la facture****************************** */
$pdf->Text(140 ,46,utf8_decode('Date de la facture : '). $row3['date_facture'], "", "", "C");
$pdf->Text(140 ,52,utf8_decode('Référence de la commande : '). $row3['id_commande'], "", "", "C");
$pdf->Text(140 ,58,utf8_decode('Numéro de client : '). $row3['id_utilisateur'], "", "", "C");
$pdf->Text(140 ,64,utf8_decode('Paiement du : '). $row3['date_reglement'], "", "", "C");
$pdf->Text(140 ,70,utf8_decode('Modalité de paiement : 30 jours'));
$pdf->Text(140 ,76,utf8_decode('Emis par : AluMe'));
$pdf->Text(140 ,82,utf8_decode('Date livraison souhaitée : '). $row3['date_liv_souhaite'], "", "", "C");

/* * ********************************************************************** */
/* * *******************Position des entetes****************************** */

/***************************************************************************************************************************************/
/**********************************Contenu des colonnes**************************************************************************/
while ($row2 = mysqli_fetch_array($rep2)) {
    $pdf->SetY($position_detail);
    $pdf->SetX(8);
    $pdf->MultiCell(109 ,8,utf8_decode(''). $row2['libelle'], 1, 'L');
    $pdf->SetY($position_detail);
    $pdf->SetX(117);
    $pdf->MultiCell(13, 8, $row2['qte'], 1, 'C');
    $pdf->SetY($position_detail);
    $pdf->SetX(130);
    $pdf->MultiCell(25, 8, $row2['netHT'], 1, 'C');
    $pdf->SetY($position_detail);
    $pdf->SetX(155);
    $pdf->MultiCell(19, 8, $row2['tva'], 1, 'C');
    $pdf->SetY($position_detail);
    $pdf->SetX(174);
    $pdf->MultiCell(26, 8, $row2['prixTTC'], 1, 'R');
    $position_detail += 8;
}
/***************************************************************************************************************************************/
/********************************Nom du fichier*********************************************************************/
$nom = 'Facture-' . $row3['id_facture'] . '.pdf';
/********************************Génération du PDF*********************************************************************/
$pdf->Output($nom, 'I');
?>
