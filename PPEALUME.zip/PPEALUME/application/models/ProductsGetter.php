<?php

class Application_Model_ProductsGetter {

    private $dbAdapter;

    public function __construct(Zend_Db_Adapter_Abstract $dbAdapter) {
        $this->dbAdapter = $dbAdapter;
    }

    public function getProducts($id_produit = null) {
        $select = $this->dbAdapter->select()->from('produit');

        if ($id_produit) {
            $select = $select->where('id_produit = ?', (int) $id_produit);
        }

        return $select->query()->fetchAll();
    }

}
