<?php

class Application_Model_Redirector {

    protected $_redirector = null;

    public function __construct(Zend_Controller_Action_Helper_Redirector $redirector) {
        $this->_redirector = $redirector;
    }

    public function redirect($controller, $action) {
        $this->_redirector->setCode(303)
                ->setExit(false)
                ->setGotoSimple($controller, $action);

        $this->_redirector->redirectAndExit();
    }

}
