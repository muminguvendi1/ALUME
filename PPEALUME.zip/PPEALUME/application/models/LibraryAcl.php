<?php

class Model_LibraryAcl extends Zend_Acl {

    public function __construct() {


        $this->add(new Zend_Acl_Resource('admin'));
        $this->add(new Zend_Acl_Resource('admin:index'), 'admin');
        $this->add(new Zend_Acl_Resource('admin:ajouter'), 'admin');
        $this->add(new Zend_Acl_Resource('admin:modifier'), 'admin');
        $this->add(new Zend_Acl_Resource('admin:supprimer'), 'admin');


        $this->add(new Zend_Acl_Resource('affectation'));
        $this->add(new Zend_Acl_Resource('affectation:index'), 'affectation');
        $this->add(new Zend_Acl_Resource('affectation:ajouter'), 'affectation');
        $this->add(new Zend_Acl_Resource('affectation:modifier'), 'affectation');
        $this->add(new Zend_Acl_Resource('affectation:supprimer'), 'affectation');



        $this->add(new Zend_Acl_Resource('authentication'));
        $this->add(new Zend_Acl_Resource('authentication:admin'), 'authentication');
        $this->add(new Zend_Acl_Resource('authentication:connexion'), 'authentication');
        $this->add(new Zend_Acl_Resource('authentication:deconnexion'), 'authentication');


        $this->add(new Zend_Acl_Resource('contact'));
        $this->add(new Zend_Acl_Resource('contact:index'), 'contact');

        $this->add(new Zend_Acl_Resource('fenetre'));
        $this->add(new Zend_Acl_Resource('fenetre:Index'), 'fenetre');
        $this->add(new Zend_Acl_Resource('fenetre:fiche'), 'fenetre');


        $this->add(new Zend_Acl_Resource('commande'));
        $this->add(new Zend_Acl_Resource('commande:Index'), 'commande');


        $this->add(new Zend_Acl_Resource('fournisseur'));
        $this->add(new Zend_Acl_Resource('fournisseur:index'), 'fournisseur');
        $this->add(new Zend_Acl_Resource('fournisseur:ajouter'), 'fournisseur');
        $this->add(new Zend_Acl_Resource('fournisseur:activer'), 'fournisseur');
        $this->add(new Zend_Acl_Resource('fournisseur:modifier'), 'fournisseur');
        $this->add(new Zend_Acl_Resource('fournisseur:supprimer'), 'fournisseur');


        $this->add(new Zend_Acl_Resource('index'));
        $this->add(new Zend_Acl_Resource('index:index'), 'index');

        $this->add(new Zend_Acl_Resource('membres'));
        $this->add(new Zend_Acl_Resource('membres:index'), 'membres');
        $this->add(new Zend_Acl_Resource('membres:inscription'), 'membres');
        $this->add(new Zend_Acl_Resource('membres:profil'), 'membres');
        $this->add(new Zend_Acl_Resource('membres:facture'), 'membres');

        $this->add(new Zend_Acl_Resource('portail'));
        $this->add(new Zend_Acl_Resource('portail:index'), 'portail');
        $this->add(new Zend_Acl_Resource('portail:fiche'), 'portail');

        $this->add(new Zend_Acl_Resource('porte'));
        $this->add(new Zend_Acl_Resource('porte:index'), 'porte');
        $this->add(new Zend_Acl_Resource('porte:fiche'), 'porte');


        $this->add(new Zend_Acl_Resource('produit'));
        $this->add(new Zend_Acl_Resource('produit:index'), 'produit');
        $this->add(new Zend_Acl_Resource('produit:ajouter'), 'produit');
        $this->add(new Zend_Acl_Resource('produit:modifier'), 'produit');
        $this->add(new Zend_Acl_Resource('produit:desactiver'), 'produit');
        $this->add(new Zend_Acl_Resource('produit:stocker'), 'produit');
        $this->add(new Zend_Acl_Resource('produit:modifierstock'), 'produit');


        $this->add(new Zend_Acl_Resource('representant'));
        $this->add(new Zend_Acl_Resource('representant:index'), 'representant');
        $this->add(new Zend_Acl_Resource('representant:ajouter'), 'representant');
        $this->add(new Zend_Acl_Resource('representant:modifier'), 'representant');
        $this->add(new Zend_Acl_Resource('representant:supprimer'), 'representant');

        $this->add(new Zend_Acl_Resource('categorie'));
        $this->add(new Zend_Acl_Resource('categorie:Index'), 'categorie');
        $this->add(new Zend_Acl_Resource('categorie:ajouter'), 'categorie');
        $this->add(new Zend_Acl_Resource('categorie:modifier'), 'categorie');
        $this->add(new Zend_Acl_Resource('categorie:supprimer'), 'categorie');

        $this->add(new Zend_Acl_Resource('veranda'));
        $this->add(new Zend_Acl_Resource('veranda:index'), 'veranda');
        $this->add(new Zend_Acl_Resource('veranda:fiche'), 'veranda');

        $this->add(new Zend_Acl_Resource('error'));
        $this->add(new Zend_Acl_Resource('error:error'), 'error');

        $this->add(new Zend_Acl_Resource('panier'));
        $this->add(new Zend_Acl_Resource('panier:index'), 'panier');
        $this->add(new Zend_Acl_Resource('panier:ajouter'), 'panier');
        $this->add(new Zend_Acl_Resource('panier:supprimer'), 'panier');
        $this->add(new Zend_Acl_Resource('panier:vider'), 'panier');
        $this->add(new Zend_Acl_Resource('panier:commander'), 'panier');

        $this->addRole(new Zend_Acl_Role('user'));
        $this->addRole(new Zend_Acl_Role('representant'));
        $this->addRole(new Zend_Acl_Role('admin'));



        $this->allow('admin', array('contact', 'admin', 'commande', 'panier', 'affectation', 'fenetre', 'fournisseur', 'index', 'portail', 'porte', 'produit', 'representant', 'categorie', 'veranda', 'authentication', 'membres', 'error'), array('fiche', 'activer', 'desactiver', 'ligne', 'supprimer-ligne', 'ajouter', 'modifier', 'supprimer', 'index', 'admin', 'connexion', 'deconnexion', 'profil', 'stocker', 'modifierstock', 'error', 'vider', 'facture'));

        $this->allow('user', array('contact', 'fenetre', 'index', 'portail', 'porte', 'veranda', 'authentication', 'membres', 'panier'), array('fiche', 'index', 'connexion', 'deconnexion', 'profil', 'ajouter', 'supprimer', 'vider', 'commander', 'etat', 'facture'));

        $this->allow('representant', array('contact', 'fenetre', 'index', 'portail', 'porte', 'veranda', 'authentication', 'membres', 'panier'), array('fiche', 'index', 'connexion', 'deconnexion', 'ajouter', 'supprimer', 'vider', 'commander', 'etat', 'facture'));
    }

}
