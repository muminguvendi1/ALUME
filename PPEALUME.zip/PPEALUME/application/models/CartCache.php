<?php

class Application_Model_CartCache {

    const cartID = 'Panier';

}
