<?php

class Application_Model_DbTable_Fournisseur extends Zend_Db_Table_Abstract {

    protected $_name = 'fournisseur';

    //used fournisseur
    public function rechercherFournisseur($id_fournisseur) {
        $row = $this->fetchRow('id_fournisseur = ' . (int) $id_fournisseur);
        if (!$row) {
            throw new Exception("Cette famille $id_fournisseur est introuvable");
        }
        return $row->toArray();
    }

    //used fournisseur
    public function selectAllFournisseur() {
        $select = $this->select()->from('fournisseur');
        $select->where('actif = 1');

        return $select->query()->fetchAll();
    }

        //used fournisseur
    public function selectAllDesactive() {
        $select = $this->select()->from('fournisseur');
        $select->where('actif = 0');

        return $select->query()->fetchAll();
    }
    
    //used fourniseur
    public function ajouterFournisseur($nom_societe, $nom_contact, $prenom_contact, $tel_contact, $adresse_fournisseur, $ville_fournisseur, $CP_fournisseur) {
        $data = array('nom_societe' => $nom_societe,
            'nom_contact' => $nom_contact,
            'prenom_contact' => $prenom_contact,
            'tel_contact' => $tel_contact,
            'adresse_fournisseur' => $adresse_fournisseur,
            'ville_fournisseur' => $ville_fournisseur,
            'CP_fournisseur' => $CP_fournisseur);
        $this->insert($data);
    }

    //used fournisseur
    public function modifierFournisseur($id_fournisseur, $nom_societe, $nom_contact, $prenom_contact, $tel_contact, $adresse_fournisseur, $ville_fournisseur, $CP_fournisseur) {
        $data = array('nom_societe' => $nom_societe,
            'nom_contact' => $nom_contact,
            'prenom_contact' => $prenom_contact,
            'tel_contact' => $tel_contact,
            'adresse_fournisseur' => $adresse_fournisseur,
            'ville_fournisseur' => $ville_fournisseur,
            'CP_fournisseur' => $CP_fournisseur,
        );
        $this->update($data, 'id_fournisseur = ' . (int) $id_fournisseur);
    }

    
    //used fournisseur
    public function activerFournisseur($id_fournisseur) {
        $data = array('actif' => 1);
        $this->update($data, 'id_fournisseur = ' . (int) $id_fournisseur);
    }    
    
    //used fournisseur
    public function desactiverFournisseur($id_fournisseur) {
        $data = array('actif' => 0);
        $this->update($data, 'id_fournisseur = ' . (int) $id_fournisseur);
    }

}
