<?php

class Application_Model_DbTable_Produit extends Zend_Db_Table_Abstract {

    protected $_name = 'produit';

    //used produit
    public function obtenirProduit($id_produit) {
        $row = $this->fetchRow('id_produit = ' . (int) $id_produit);
        if (!$row) {
            throw new Exception("Le produit $id_produit n'existe pas");
        }
        return $row->toArray();
    }

    //Used produit
    public function selectAllProduit() {
        $select = $this->select()->from('produit');
        $select->where('actif = 1');

        return $select->query()->fetchAll();
    }

//used produit
    public function ajouterProduit($photo_produit, $designation_produit, $prix_produit, $description_produit, $quantite_stock, $id_categorie, $id_fournisseur) {
        $data = array('photo_produit' => $photo_produit,
            'designation_produit' => $designation_produit,
            'prix_produit' => $prix_produit,
            'description_produit' => $description_produit,
            'quantite_stock' => $quantite_stock,
            'id_categorie' => $id_categorie,
            'id_fournisseur' => $id_fournisseur);
        $this->insert($data);
    }

//used produit
    public function modifierProduit($photo_produit, $id_produit, $designation_produit, $prix_produit, $description_produit, $quantite_stock, $id_categorie, $id_fournisseur) {
        $data = array('photo_produit' => $photo_produit,
            'designation_produit' => $designation_produit,
            'prix_produit' => $prix_produit,
            'description_produit' => $description_produit,
            'quantite_stock' => $quantite_stock,
            'id_categorie' => $id_categorie,
            'id_fournisseur' => $id_fournisseur);
        $this->update($data, 'id_produit = ' . (int) $id_produit);
    }

    //Used produit
    public function desactiverProduit($id_produit) {
        $data = array('actif' => 0);
        $this->update($data, 'id_produit = ' . (int) $id_produit);
    }

    //used produit
    public function listeProduitStock($id_produit) {
        $select = $this->select(zend_Db_table::SELECT_WITH_FROM_PART);
        $select->setIntegrityCheck(false)
                ->join('approvision', 'produit.id_produit = approvision.id_produit')
                ->where('approvision.id_produit = ?', (int) $id_produit);
        return $this->fetchAll($select);
    }

    //Used Fenetre
    public function produit($id_categorie) {
        $select = $this->select()->from('produit');

        if ($id_categorie) {
            $select = $select->where('id_categorie = ?', (int) $id_categorie)
                    ->where('actif = 1');
        }

        return $select->query()->fetchAll();
    }

    //Used fenetre
    public function ficheProduit($id_produit) {
        $select = $this->select()->from('produit');

        if ($id_produit) {
            $select = $select->where('id_produit = ?', (int) $id_produit);
        }
        return $select->query()->fetchAll();
    }

    //A SUPPRIMER
    public function allProduct() {
        $select = $this->select()->from('produit');

        return $select->query()->fetchAll();
    }

}
