<?php

class Application_Model_DbTable_Utilisateur extends Zend_Db_Table_Abstract {

    protected $_name = 'utilisateur';

    //Used affectationClient , used membres, used representant
    public function rechercherClient($id_utilisateur) {
        $row = $this->fetchRow('id_utilisateur = ' . (int) $id_utilisateur);
        if (!$row) {
            throw new Exception("Le client $id_utilisateur n'existe pas");
        }
        return $row->toArray();
    }

    //Used AffectationClient
    public function selectAllClientRepresentant() {
        $sql = $this->select()->setIntegrityCheck(false)
                ->from(array('u' => 'utilisateur'), array('id_utilisateur as id_utilisateurClient', 'nom', 'prenom', 'adresse', 'tel', 'email'))
                ->join(array('p' => 'professionnel'), 'u.id_utilisateur = p.id_utilisateur and p.id_representant is not null')
                ->join(array('u1' => 'utilisateur'), 'u1.id_utilisateur = p.id_representant', array('nom as nomRepresentant', 'prenom as prenomRepresentant'));
        return $this->fetchAll($sql);
    }

// select u.nom, u.prenom, u1.nom, u1.prenom from utilisateur u, utilisateur u1, representant r 
//         where u.id_representant = r.id_representant and u1.id_utilisateur = r.id_utilisateur and r.id_representant in(select id_representant from utilisateur);
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    public function verifUser($nom_utilisateur) {

        $select = $this->select();
        $select->from('professionnel')
                ->where('nom_utilisateur = ?', $nom_utilisateur);

        return $this->fetchRow($select);
    }

    //used membres, used representant
    public function ajouter($nom_utilisateur, $mot_de_passe, $nom, $prenom, $adresse, $ville, $code_postal, $tel, $email, $role) {
        if ($role) {
            $data = array(
                'nom_utilisateur' => $nom_utilisateur,
                'mot_de_passe' => $mot_de_passe,
                'nom' => $nom,
                'prenom' => $prenom,
                'adresse' => $adresse,
                'ville' => $ville,
                'code_postal' => $code_postal,
                'email' => $email,
                'tel' => $tel,
                'role' => 'representant'
            );
            $this->insert($data);
        } else {
            $data = array(
                'nom_utilisateur' => $nom_utilisateur,
                'mot_de_passe' => $mot_de_passe,
                'nom' => $nom,
                'prenom' => $prenom,
                'adresse' => $adresse,
                'ville' => $ville,
                'code_postal' => $code_postal,
                'email' => $email,
                'tel' => $tel
            );
            $this->insert($data);
        }
    }

    //used
    public function selectProfessionnel() {
        $sql = $this->select()->setIntegrityCheck(false)
                ->from(array('u' => 'utilisateur'), array('id_utilisateur as id_utilisateurClient', 'nom', 'prenom', 'adresse', 'tel', 'email'))
                ->join(array('p' => 'professionnel'), 'u.id_utilisateur = p.id_utilisateur and p.id_representant is null');
        return $this->fetchAll($sql);
    }


    //uSED MEMBES, used representant
    public function majProfil($nom_utilisateur, $mot_de_passe, $nom, $prenom, $adresse, $ville, $code_postal, $email, $tel, $id_utilisateur) {
        $data = array(
            'nom_utilisateur' => $nom_utilisateur,
            'mot_de_passe' => $mot_de_passe,
            'nom' => $nom,
            'prenom' => $prenom,
            'adresse' => $adresse,
            'ville' => $ville,
            'code_postal' => $code_postal,
            'email' => $email,
            'tel' => $tel
        );
        $this->update($data, 'id_utilisateur = ' . (int) $id_utilisateur);
    }

    //used repreesntant
    public function supprimerRepresentant($id_utilisateur) {
        $this->delete('id_utilisateur = ' . (int) $id_utilisateur);
    }

}
