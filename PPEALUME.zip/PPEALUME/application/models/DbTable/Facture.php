<?php

class Application_Model_DbTable_Facture extends Zend_Db_Table_Abstract {

    protected $_name = 'facture';

    //USED COMMANDE
    public function obtenirLigne($id_commande) {
        $row = $this->fetchRow('id_facture = ' . (int) $id_commande);
        if (!$row) {
            throw new Exception("La facture $id_commande n'existe pas");
        }
        return $row->toArray();
    }

    //used panier
    public function commander($adresse_livraison, $ville_livraison, $cp_livraison, $adresse_facturation, $ville_facturation, $cp_facturation) {
        $data = array('adresse_livraison' => $adresse_livraison,
            'ville_livraison' => $ville_livraison,
            'cp_livraison' => $cp_livraison,
            'adresse_facturation' => $adresse_facturation,
            'ville_facturation' => $ville_facturation,
            'cp_facturation' => $cp_facturation);
        $this->insert($data);
    }

    //Used commande
    public function updateFacture($adresse_livraison, $ville_livraison, $cp_livraison, $adresse_facturation, $ville_facturation, $cp_facturation, $id_commande) {
        $data = array('adresse_livraison' => $adresse_livraison,
            'ville_livraison' => $ville_livraison,
            'cp_livraison' => $cp_livraison,
            'adresse_facturation' => $adresse_facturation,
            'ville_facturation' => $ville_facturation,
            'cp_facturation' => $cp_facturation,
        );
        $this->update($data, 'id_facture = ' . (int) $id_commande);
    }

    public function header() {
        $adresse = $this->select()->setIntegrityCheck(false)
                ->from(array('facture'), array('id_facture', 'adresse_livraison', 'ville_livraison', 'cp_livraison'));
        return $this->fetchAll($adresse);
    }

    //Used commande
    public function supprimerCommande($id_commande) {
        $this->delete('id_facture = ' . (int) $id_commande);
    }

    public function commande() {
        
    }

    public function footer() {
        
    }

}
