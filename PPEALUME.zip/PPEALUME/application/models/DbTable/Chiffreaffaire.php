<?php

class Application_Model_DbTable_Chiffreaffaire extends Zend_Db_Table_Abstract {

    protected $_name = 'statistiques';
    protected $_primary = 'id_utilisateur';

    
    
    public function selectAll() {
        $select = $this->select()
                ->from(array('s' => 'statistiques'), array('client' => new Zend_Db_Expr("CONCAT(nom, ' ', prenom)"), 'ca' => new Zend_Db_Expr('SUM(total_ttc)'), 'annee' => new Zend_Db_Expr('LEFT(date_commande, 7)')))
                ->join(array('r' => 'representant'), 's.id_utilisateur = r.id_utilisateur')
                ->join(array('p' => 'professionnel'), 'r.id_utilisateur = p.id_representant')
                ->where("DATE_FORMAT(date_commande, '%Y-%m') = ?", new Zend_Db_Expr('LEFT(CURDATE(), 7)'))
                ->group('p.id_representant')

                ->setIntegrityCheck(false);


        return $this->fetchAll($select);
    }


    
}
