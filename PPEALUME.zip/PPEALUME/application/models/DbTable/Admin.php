<?php

class Application_Model_DbTable_Admin extends Zend_Db_Table_Abstract {

    protected $_name = 'admin';

//used membres
    public function verifUser($id_admin) {
        $row = $this->fetchRow('id_admin = ' . (int) $id_admin);
        if (!$row) {
            throw new Exception("L'admin $id_admin n'existe pas");
        }
        return $row->toArray();
    }

    // USED ADMIN
    public function rechercherAdmin($id_admin) {
        $row = $this->fetchRow('id_admin = ' . (int) $id_admin);
        if (!$row) {
            throw new Exception("L'admin $id_admin est introuvable");
        }
        return $row->toArray();
    }

    //MAJADMIN USED ADMIN, used membres
    public function majAdmin($id_admin, $nom_utilisateur, $mot_de_passe) {
        $data = array(
            'mot_de_passe' => $mot_de_passe,
            'nom_utilisateur' => $nom_utilisateur
        );
        $this->update($data, 'id_admin = ' . (int) $id_admin);
    }

    //USED ADMIN
    public function ajouter($nom_utilisateur, $mot_de_passe) {
        $data = array(
            'nom_utilisateur' => $nom_utilisateur,
            'mot_de_passe' => $mot_de_passe
        );
        $this->insert($data);
    }

    //USED ADMIN
    public function supprimerAdmin($id_admin) {
        $this->delete('id_admin = ' . (int) $id_admin);
    }

    //used admin
    public function proSto($nom_utilisateur, $mot_de_passe, $role) {
        $sql = "CALL connexion('$nom_utilisateur', '$mot_de_passe', '$role')";
        $this->_db->exec($sql);
    }

}
