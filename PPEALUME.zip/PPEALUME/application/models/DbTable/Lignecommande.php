<?php

class Application_Model_DbTable_Lignecommande extends Zend_Db_Table_Abstract {

    protected $_name = 'lignecommande';

    //USED COMMANDE
    public function obtenirLigne($id_ligne) {
        $row = $this->fetchRow('id_ligne = ' . (int) $id_ligne);
        if (!$row) {
            throw new Exception("La ligne de commande $id_ligne n'existe pas");
        }
        return $row->toArray();
    }

    //used commande
    public function nbLigne($id_commande) {
        $select = $this->select()
                ->from(array('lc' => 'lignecommande'), array('id_commande'))
                ->where('lc.id_commande = ? ', $id_commande)
                ->setIntegrityCheck(false);

        return $this->fetchAll($select)->count();
    }

    //Used commande
    public function updateLignecommande($qte, $id_ligne) {
        $data = array('quantite_commande' => $qte
        );
        $this->update($data, 'id_ligne = ' . (int) $id_ligne);
    }

    //used panier
    public function commander($id, $qte) {
        $data = array('id_produit' => $id,
            'quantite_commande' => $qte);
        $this->insert($data);
    }

    //used commande
    public function supprimerLigne($id_ligne) {
        $this->delete('id_ligne = ' . (int) $id_ligne);
    }

    //USED COMMANDE
    public function supprimerCommande($id_commande) {
        $this->delete('id_commande = ' . (int) $id_commande);
    }

}
