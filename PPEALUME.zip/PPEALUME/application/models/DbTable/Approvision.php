<?php

class Application_Model_DbTable_Approvision extends Zend_Db_Table_Abstract {

    protected $_name = 'approvision';

    public function rechercherStock($id_stock) {
        $row = $this->fetchRow('id_stock = ' . (int) $id_stock);
        if (!$row) {
            throw new Exception("le stock $id_stock est introuvable");
        }
        return $row->toArray();
    }

    //used produit
    public function ajouterStock($date_stock, $quantite_stock, $id_fournisseur, $id_produit) {
        if ($date_stock < new Zend_Db_Expr('NOW()')) {
            $date_stock = new Zend_Db_Expr('NOW()');
        }

        $data = array('date_stock' => $date_stock,
            'quantite_stock' => $quantite_stock,
            'id_fournisseur' => $id_fournisseur,
            'id_produit' => $id_produit);
        $this->insert($data);
    }

    //Used produit
    public function modifierStock($id_stock, $quantite) {
        $data = array('quantite' => $quantite);
        $this->update($data, 'id_stock = ' . (int) $id_stock);
        
    }

}
