<?php

class Application_Model_DbTable_Lignefacture extends Zend_Db_Table_Abstract {

    protected $_name = 'lignefacture';

    //used panier
    public function commander($id) {
        $data = array('id_produit' => $id);
        $this->insert($data);
    }

    //used commande
    public function supprimerLigne($id_ligne) {
        $this->delete('id_ligne = ' . (int) $id_ligne);
    }

//USED COMMANDE
    public function supprimerCommande($id_commande) {
        $this->delete('id_facture = ' . (int) $id_commande);
    }

}
