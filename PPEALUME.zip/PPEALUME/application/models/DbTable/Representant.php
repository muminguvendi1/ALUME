<?php

class Application_Model_DbTable_Representant extends Zend_Db_Table_Abstract {

    protected $_name = 'representant';

    //used representant
    public function rechercheRepresentant($id_utilisateur) {
        $row = $this->fetchRow('id_utilisateur = ' . (int) $id_utilisateur);
        if (!$row) {
            throw new Exception("Le representant $id_utilisateur n'existe pas");
        }
        return $row->toArray();
    }

    //used
    public function selectRepresentants() {
        $select = $this->select()
                ->from(array('u' => 'utilisateur'), array('nom'))
                ->join(array('r' => 'representant'), 'u.id_utilisateur = r.id_utilisateur')
                ->setIntegrityCheck(false);

        return $this->fetchAll($select);
    }

    //used representant
    public function listeRepresentants() {
        $select = $this->select()
                ->from(array('u' => 'utilisateur'), array('id_utilisateur', 'nom_utilisateur', 'nom', 'prenom', 'adresse', 'ville', 'code_postal', 'tel', 'email'))
                ->join(array('r' => 'representant'), 'u.id_utilisateur = r.id_utilisateur', array('id_utilisateur', 'date_arrivee', 'salaire', 'date_naissance'))
                ->setIntegrityCheck(false);

        return $this->fetchAll($select);
    }

    //used representant
    public function ajouterRepresentant($date_naissance, $sexe, $date_arrivee, $salaire) {
        $data = array('date_naissance' => $date_naissance,
            'sexe' => $sexe,
            'date_arrivee' => $date_arrivee,
            'salaire' => $salaire);
        $this->insert($data);
    }

    //used representant
    public function modifierRepresentant($id_utilisateur, $date_naissance, $sexe, $date_arrivee, $salaire) {
        $data = array('date_naissance' => $date_naissance,
            'sexe' => $sexe,
            'date_arrivee' => $date_arrivee,
            'salaire' => $salaire);

        $this->update($data, 'id_utilisateur = ' . (int) $id_utilisateur);
    }

    //used representant
    public function supprimerRepresentant($id_utilisateur) {
        $this->delete('id_utilisateur = ' . (int) $id_utilisateur);
    }

}
