<?php

class Application_Model_DbTable_Commande extends Zend_Db_Table_Abstract {

    protected $_name = 'commande';

    //USED COMMANDE
    public function obtenirCommande($id_commande) {
        $row = $this->fetchRow('id_commande = ' . (int) $id_commande);
        if (!$row) {
            throw new Exception("La commande $id_commande n'existe pas");
        }
        return $row->toArray();
    }

    //used memrbes
    public function verifUserCommande($id_commande, $id_utilisateur) {
        $select = $this->select()
                ->from(array('c' => 'commande'), array('id_commande'))
                ->where('c.id_commande = ? ', $id_commande)
                ->where('c.id_utilisateur = ? ', $id_utilisateur)
                ->setIntegrityCheck(false);

        return $this->fetchAll($select)->count();
    }

    //used panier
    public function commander($id_utilisateur, $date_livraison) {
        $data = array('id_utilisateur' => $id_utilisateur,
            'date_commande' => new Zend_Db_Expr('NOW()'),
            'date_liv_souhaite' => $date_livraison);
        $this->insert($data);
    }

    //used membres
    public function commandes($id_utilisateur) {
        $select = $this->select()
                ->from(array('u' => 'utilisateur'), array('nom_utilisateur', 'id_utilisateur'))
                ->join(array('c' => 'commande'), 'c.id_utilisateur = u.id_utilisateur', array('id_commande', 'date_commande', 'date_liv_souhaite', 'etat'))
                ->where('c.id_utilisateur = ? ', $id_utilisateur)
                ->setIntegrityCheck(false);

        return $this->fetchAll($select);
    }

    //A SUPPRIMER
    public function commandesAdmin($id_admin) {
        $select = $this->select()
                ->from(array('a' => 'admin'), array('nom_utilisateur', 'id_admin'))
                ->join(array('c' => 'commande'), 'c.id_utilisateur = a.id_admin', array('id_commande', 'date_commande', 'date_liv_souhaite'))
                ->where('a.id_admin = ? ', $id_admin)
                ->setIntegrityCheck(false);

        return $this->fetchAll($select);
    }

    //USED Commande
    public function gestionCommandes($id_commande) {
        $select = $this->select()
                ->from(array('c' => 'commande'), array('date_liv_souhaite'))
                ->join(array('f' => 'facture'), 'c.id_commande = f.id_facture', array('adresse_livraison', 'ville_livraison', 'cp_livraison', 'adresse_facturation', 'ville_facturation', 'cp_facturation'))
                ->join(array('lc' => 'lignecommande'), 'c.id_commande = lc.id_commande', array('id_ligne', 'id_produit', 'id_commande', 'quantite_commande'))
                ->where('c.id_commande = ? ', $id_commande)
                ->setIntegrityCheck(false);
        return $this->fetchAll($select);
    }

    //USED COMMANDE
    public function updateCommande($date_liv_souhaite, $id_commande) {
        $data = array('date_liv_souhaite' => $date_liv_souhaite);
        $this->update($data, 'id_commande = ' . (int) $id_commande);
    }

    //USED COMMANDE
    public function supprimerCommande($id_commande) {
        $this->delete('id_commande = ' . (int) $id_commande);
    }

}
