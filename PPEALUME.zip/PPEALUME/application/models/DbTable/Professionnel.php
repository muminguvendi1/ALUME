<?php

class Application_Model_DbTable_Professionnel extends Zend_Db_Table_Abstract {

    protected $_name = 'professionnel';

    //used membres
    public function getParam($id_utilisateur) {
        $row = $this->fetchRow('id_utilisateur = ' . (int) $id_utilisateur);
        if (!$row) {
            throw new Exception("L'utilisateur $id_utilisateur n'existe pas");
        }
        return $row->toArray();
    }

//used admin
    public function recherche($id_utiliateur) {

        $select = $this->select();
        $select->from('professionnel')
                ->where('id_utilisateur = ?', $id_utiliateur);

        return $this->fetchRow($select);
    }

    //used membres
    public function heritage($activite, $raison_sociale, $numero_siret) {
        $data = array(
            'activite' => $activite,
            'raison_sociale' => $raison_sociale,
            'numero_siret' => $numero_siret,
        );
        $this->insert($data);
    }

    //used membres
    public function majHeritage($activite, $raison_sociale, $numero_siret, $id_utilisateur) {
        $data = array(
            'activite' => $activite,
            'raison_sociale' => $raison_sociale,
            'numero_siret' => $numero_siret
        );
        $this->update($data, 'id_utilisateur = ' . (int) $id_utilisateur);
    }

    //USED AffectationClient
    public function affecterClient($id_utilisateur, $id_representant) {
        $data = array('id_representant' => $id_representant);
        $where = $this->getAdapter()->quoteInto('id_utilisateur = ?', $id_utilisateur);

        $this->update($data, $where);
    }

    //USED Affectationclient
    public function modifierClient($id_utilisateur, $id_representant) {
        $data = array('id_representant' => $id_representant);
        $this->update($data, 'id_utilisateur = ' . (int) $id_utilisateur);
    }

}
