<?php

class Application_Model_DbTable_AffectationClient extends Zend_Db_Table_Abstract {

    protected $_name = 'client';

    public function rechercherClient($id_client) {
        $row = $this->fetchRow('id_client = ' . (int) $id_client);
        if (!$row) {
            throw new Exception("Le client $id_client n'existe pas");
        }
        return $row->toArray();
    }

    public function ajouterClient($id_client, $id_representant) {
        $data = array('id_representant' => $id_representant);
        $where = $this->getAdapter()->quoteInto('id_client = ?', $id_client);

        $this->update($data, $where);
    }

    public function modifierClient($id_client, $id_representant) {
        $data = array('id_representant' => $id_representant);
        $this->update($data, 'id_client = ' . (int) $id_client);
    }

    public function supprimerClient($id_client) {
        $this->delete('id_client = ' . (int) $id_client);
    }

}
