<?php

class Application_Model_DbTable_Particulier extends Zend_Db_Table_Abstract {

    protected $_name = 'particulier';

    //used membres
    public function getParam($id_utilisateur) {

        $row = $this->fetchRow('id_utilisateur = ' . (int) $id_utilisateur);
        if (!$row) {
            throw new Exception("L'utilisateur $id_utilisateur n'existe pas");
        }
        return $row->toArray();
    }

    //used admin
    public function recherche($id_utiliateur) {

        $select = $this->select();
        $select->from('particulier')
                ->where('id_utilisateur = ?', $id_utiliateur);

        return $this->fetchRow($select);
    }

    //used memrbes
    public function heritage($date_naissance, $sexe) {
        $data = array(
            'date_naissance' => $date_naissance,
            'sexe' => $sexe
        );
        $this->insert($data);
    }

//used membres
    public function majHeritage($date_naissance, $sexe, $id_utilisateur) {
        $data = array(
            'date_naissance' => $date_naissance,
            'sexe' => $sexe,
        );
        $this->update($data, 'id_utilisateur = ' . (int) $id_utilisateur);
    }

}
