<?php

class Application_Model_DbTable_Categorie extends Zend_Db_Table_Abstract {

    protected $_name = 'categorie';

    //used typeproduit
    public function rechercherFamille($id_categorie) {
        $row = $this->fetchRow('id_categorie = ' . (int) $id_categorie);
        if (!$row) {
            throw new Exception("Cette famille $id_categorie est introuvable");
        }
        return $row->toArray();
    }

    public function selectAllCategorie() {
        $select = $this->select()->from('categorie');
        $select->where('actif = 1');

        return $select->query()->fetchAll();
    }

    //used categorie
    public function selectAllDesactive() {
        $select = $this->select()->from('categorie');
        $select->where('actif = 0');

        return $select->query()->fetchAll();
    }

    //type produit
    public function ajouterFamille($description_categorie) {
        $data = array('description_categorie' => $description_categorie);
        $this->insert($data);
    }

    //type produit
    public function modifierFamille($id_categorie, $description_categorie) {
        $data = array('description_categorie' => $description_categorie);
        $this->update($data, 'id_categorie = ' . (int) $id_categorie);
    }

    //used categorie
    public function desactiverFamille($id_categorie) {
        $data = array('actif' => '0');
        $this->update($data, 'id_categorie = ' . (int) $id_categorie);
    }

    //used categorie
    public function activerCategorie($id_categorie) {
        $data = array('actif' => '1');
        $this->update($data, 'id_categorie = ' . (int) $id_categorie);
    }

}
