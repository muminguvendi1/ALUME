<?php //

//class Zend_View_Helper_LoggedInAs extends Zend_View_Helper_Abstract {
//
//    public function loggedInAs() {
//        $auth = Zend_Auth::getInstance();
//        if ($auth->hasIdentity()) {
//            $nom_utilisateur = $auth->getIdentity()->nom_utilisateur;
//            $deconnexionUrl = $this->view->url(array('controller' => 'authentication',
//                'action' => 'deconnexion'), null, true);
//            return $nom_utilisateur;
//        }
//
//        $request = Zend_Controller_Front::getInstance()->getRequest();
//        $controller = $request->getControllerName();
//        $action = $request->getActionName();
//        if ($controller == 'authentication' && $action == 'index') {
//            return '';
//        }
//        $connexionUrl = $this->view->url(array('controller' => 'auth', 'action' => 'index'));
//        return '';
//    }
//
//}
