<?php

class Application_Form_ModifierAffectation extends Zend_Form {

    public function init() {
        $this->setName('client');


        $nom_client = new Zend_Form_Element_Text('nom');
        $nom_client->setLabel('Nom client')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('readonly', 'readonly')
                ->setRequired(true)
                ->addErrorMessage("Vous n'avez pas de client");

        $id_representant = new Zend_Form_Element_Select('id_representant');
        $id_representant->setLabel('Representant')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('placeholder', 'Nom de la societe')
                ->setRequired(true)
                ->addErrorMessage("Vous n'avez pas de commercial");

        $representant = new Application_Model_DbTable_Representant();
        $lstRepresentant = $representant->selectRepresentants();

        foreach ($lstRepresentant as $fp) :
            $id_representant->addMultiOption($fp->id_utilisateur, $fp->nom);
        endforeach;

        $submit = new Zend_Form_Element_Submit('Modifier');
        $submit->setAttrib('id_utilisateur', 'Modifier')
                ->setAttrib('class', 'gestion-btn');

        $this->addElements(array($nom_client, $id_representant, $submit));
    }

}
