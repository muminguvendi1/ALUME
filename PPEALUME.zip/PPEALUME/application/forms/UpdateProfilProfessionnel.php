<?php

class Application_Form_UpdateProfilProfessionnel extends Zend_Form {

    public function init() {
        $mot_de_passe = new Zend_Form_Element_Password('mot_de_passe');
        $mot_de_passe->setLabel('Mot de passe')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', 'Mot de passe');

        $nom = new Zend_Form_Element_Text('nom');
        $nom->setLabel("Nom")
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Nom de l'utilisateur");

        $prenom = new Zend_Form_Element_Text('prenom');
        $prenom->setLabel('Prenom')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Prenom de l'utilisateur");

        $adresse = new Zend_Form_Element_Text('adresse');
        $adresse->setLabel('Adresse')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[a-zA-ZÀ-ú0-9]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Adresse de l'uitilisateur");

        $ville = new Zend_Form_Element_Text('ville');
        $ville->setLabel('Ville')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[a-zA-ZÀ-ú]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Ville de l'utilisateur");

        $code_postal = new Zend_Form_Element_Text('code_postal');
        $code_postal->setLabel('Code postal')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addFilter(new Zend_Filter_StringTrim())
                ->addValidator('regex', true, array('/^[(a-zA-Z0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Code postal de l'utilisateur");

        $email_client = new Zend_Form_Element_Text('email');
        $email_client->setLabel('E-mail')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->setAttrib('placeholder', "Adresse mail de l'utilisateur")
            ->addFilters(array('StringTrim', 'StripTags'))
            ->addValidator('EmailAddress',  TRUE  )
                ->addErrorMessage("Email incorrect");

        $tel = new Zend_Form_Element_Text('tel');
        $tel->setLabel('Telephone')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->setAttrib('placeholder', 'N° de téléphone')
                ->addValidator('regex', true, array('/^[(0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte");

        $activite = new Zend_Form_Element_Text('activite');
        $activite->setLabel('Activité')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú 0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Activité de l'entreprise");

        $raison_sociale = new Zend_Form_Element_Text('raison_sociale');
        $raison_sociale->setLabel('Raison sociale')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->setAttrib('placeholder', "Raison sociale de l'entreprise")
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú 0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte");

        $numero_siret = new Zend_Form_Element_Text('numero_siret');
        $numero_siret->setLabel('N° siret')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->setAttrib('placeholder', '54786214587965')
                ->addValidator('regex', true, array('/^[(0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte");

        $modifier = new Zend_Form_Element_Submit('modifier');
        $modifier->setLabel('Mise a jour')
                ->setAttrib('class', 'form-btn');

        $this->addElements(array($mot_de_passe, $nom, $prenom, $adresse, $ville, $code_postal, $email, $tel, $activite, $raison_sociale, $numero_siret, $modifier));
        $this->setMethod('post');
        $this->setAction(zend_controller_front::getInstance()->getBaseUrl() . '/membres/profil');
    }

}
