<?php

class Application_Form_SupprimerFournisseur extends Zend_Form {

    public function init() {
        $this->setName('fournisseur');

        $nom_societe = new Zend_Form_Element_Text('nom_societe');
        $nom_societe->setLabel('Nom societe')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $nom_contact = new Zend_Form_Element_Text('nom_contact');
        $nom_contact->setLabel('Nom contact')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $prenom_contact = new Zend_Form_Element_Text('prenom_contact');
        $prenom_contact->setLabel('Prenom contact')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $tel_contact = new Zend_Form_Element_Text('tel_contact');
        $tel_contact->setLabel('N° tel')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $adresse_fournisseur = new Zend_Form_Element_Text('adresse_fournisseur');
        $adresse_fournisseur->setLabel('Adresse')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $CP_fournisseur = new Zend_Form_Element_Text('CP_fournisseur');
        $CP_fournisseur->setLabel('Code postal')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);



        $submit = new Zend_Form_Element_Submit('Désactiver');
        $submit->setAttrib('id_fournisseur', 'desactiver')
                ->setAttrib('class', 'gestion-btn');

        $this->addElements(array($nom_societe, $nom_contact, $prenom_contact, $tel_contact, $adresse_fournisseur, $CP_fournisseur, $submit));
    }

}

?>