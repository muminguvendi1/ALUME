<?php

class Application_Form_SupprimerCommande extends Zend_Form {

    public function __construct($options = null) {
        parent::__construct($options);

        $id_commande = new Zend_Form_Element_Text('id_commande');
        $id_commande->setLabel("N° commande")
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('readonly', 'readonly');

        $id_utilisateur = new Zend_Form_Element_Text('id_utilisateur');
        $id_utilisateur->setLabel("N° utilisateur")
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('readonly', 'readonly');

        $date_commande = new Zend_Form_Element_Text('date_commande');
        $date_commande->setLabel('Date commande')
                ->setAttrib('class', 'users-form')
                ->setAttrib('readonly', 'readonly');

        $date_liv_souhaite = new Zend_Form_Element_Text('date_liv_souhaite');
        $date_liv_souhaite->setLabel('Date livraison')
                ->setAttrib('class', 'users-form')
                ->setAttrib('readonly', 'readonly');

        $submit = new Zend_Form_Element_Submit('Supprimer');
        $submit->setAttrib('commande', 'Supprimer')
                ->setAttrib('class', 'gestion-btn');

        $this->addElements(array($id_commande, $id_utilisateur, $date_commande, $date_liv_souhaite, $submit));
    }

}
