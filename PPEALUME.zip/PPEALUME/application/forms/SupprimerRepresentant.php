<?php

class Application_Form_SupprimerRepresentant extends Zend_Form {

    public function init() {
        $this->setName('representant');

        $nom = new Zend_Form_Element_Text('nom');
        $nom->setLabel('Nom')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $prenom = new Zend_Form_Element_Text('prenom');
        $prenom->setLabel('Prenom')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $adresse = new Zend_Form_Element_Text('adresse');
        $adresse->setLabel('Adressse')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $ville = new Zend_Form_Element_Text('ville');
        $ville->setLabel('Ville')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $cp = new Zend_Form_Element_Text('code_postal');
        $cp->setLabel('Code postal')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $submit = new Zend_Form_Element_Submit('Supprimer');
        $submit->setAttrib('id_representant', 'Supprimer')
                ->setAttrib('class', 'gestion-btn');

        $this->addElements(array($nom, $prenom, $adresse, $ville, $cp, $submit));
    }

}
