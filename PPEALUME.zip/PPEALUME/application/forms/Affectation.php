<?php

class Application_Form_Affectation extends Zend_Form {

    public function init() {
        $id_client = new Zend_Form_Element_Select('id_utilisateur');
        $id_client->setLabel('Client')
                ->setAttrib('class', 'gestion-form')
                ->setRequired(true)
                ->addErrorMessage("Vos clients ont déja un fournisseur");

        $id_representant = new Zend_Form_Element_Select('id_representant');
        $id_representant->setLabel('Representant')
                ->setAttrib('class', 'gestion-form')
                ->setRequired(true)
                ->addErrorMessage("Vous n'avez pas de commercial");




        $user = new Application_Model_DbTable_Utilisateur();
        $lstUser = $user->selectProfessionnel();

        $representant = new Application_Model_DbTable_Representant();
        $lstRepresentant = $representant->selectRepresentants();


        foreach ($lstUser as $fp) :
            $id_client->addMultiOption($fp->id_utilisateur, $fp->nom);
        endforeach;

        foreach ($lstRepresentant as $fp) :
            $id_representant->addMultiOption($fp->id_utilisateur, $fp->nom);
        endforeach;



        $submit = new Zend_Form_Element_Submit('Affecter');
        $submit->setAttrib('id_produit', 'affecter')
                ->setAttrib('class', 'gestion-btn');


        $this->addElements(array($id_client, $id_representant, $submit));
    }

}
