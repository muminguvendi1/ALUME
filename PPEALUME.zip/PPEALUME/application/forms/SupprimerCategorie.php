<?php

class Application_Form_SupprimerCategorie extends Zend_Form {

    public function init() {

        $this->setName('categorie');

        $id_categorie = new Zend_Form_Element_Text('id_categorie');
        $id_categorie->setLabel('N° de categorie')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $description_categorie = new Zend_Form_Element_Text('description_categorie');
        $description_categorie->setLabel('Désignation')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $submit = new Zend_Form_Element_Submit('Désactiver');
        $submit->setAttrib('id_categorie', 'desactiver')
                ->setAttrib('class', 'gestion-btn');

        $this->addElements(array($id_categorie, $description_categorie, $submit));
    }

}
