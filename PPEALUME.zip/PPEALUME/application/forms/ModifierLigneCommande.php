<?php

class Application_Form_ModifierLigneCommande extends Zend_Form {

    public function __construct($options = null) {
        parent::__construct($options);



        $id_commande = new Zend_Form_Element_Text('id_commande');
        $id_commande->setLabel("N° de commande")
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('readonly', 'readonly');


        $id_produit = new Zend_Form_Element_Text('id_produit');
        $id_produit->setLabel("N° de produit")
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('readonly', 'readonly');


        $date_liv_souhaite = new Zend_Form_Element_Text('date_liv_souhaite');
        $date_liv_souhaite->setLabel('Date de livraison souhaitée')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->setAttrib('placeholder', 'AAAA-MM-JJ')
                ->addValidator('regex', true, array('/^\d{4}\-\d{2}\-\d{2}$/'))
                ->addErrorMessage("Saisie incorrecte");

        $adresse_livraison = new Zend_Form_Element_Text('adresse_livraison');
        $adresse_livraison->setLabel('Adresse de livraison')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[0-9a-zA-ZÀ-ú]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Adresse de livraison");

        $ville_livraison = new Zend_Form_Element_Text('ville_livraison');
        $ville_livraison->setLabel('Ville de livraison')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[a-zA-ZÀ-ú]{1}[a-zA-Z 0-9 -]*$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Ville de livraison");


        $cp_livraison = new Zend_Form_Element_Text('cp_livraison');
        $cp_livraison->setLabel('Code postal de livraison')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-Z0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Code postal");


        $adresse_facturation = new Zend_Form_Element_Text('adresse_facturation');
        $adresse_facturation->setLabel('Adresse de facturation')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[0-9a-zA-ZÀ-ú]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Adresse de facturation");

        $ville_facturation = new Zend_Form_Element_Text('ville_facturation');
        $ville_facturation->setLabel('ville de facturation')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[a-zA-ZÀ-ú]{1}[a-zA-Z 0-9 -]*$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Ville de facturation");

        $cp_facturation = new Zend_Form_Element_Text('cp_facturation');
        $cp_facturation->setLabel('Code postal de facturation')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-Z 0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Code postal de facturation");


        $valeurs = array(array('id' => '1', 'valeur' => '1'),
            array('id' => '2', 'valeur' => '2'),
            array('id' => '3', 'valeur' => '3'),
            array('id' => '4', 'valeur' => '4'),
            array('id' => '5', 'valeur' => '5'),
            array('id' => '6', 'valeur' => '6'),
            array('id' => '7', 'valeur' => '7'),
            array('id' => '8', 'valeur' => '8'),
            array('id' => '9', 'valeur' => '9'),
            array('id' => '10', 'valeur' => '10'),
            array('id' => '11', 'valeur' => '11'),
            array('id' => '12', 'valeur' => '12'),
            array('id' => '13', 'valeur' => '13'),
            array('id' => '14', 'valeur' => '14'),
            array('id' => '15', 'valeur' => '15'),
            array('id' => '16', 'valeur' => '16'),
            array('id' => '17', 'valeur' => '17'),
            array('id' => '18', 'valeur' => '18'),
            array('id' => '19', 'valeur' => '19'),
            array('id' => '20', 'valeur' => '20')
        );

        $qte = $this->createElement('select', 'quantite_commande');
        $qte->setLabel('Quantité')
                ->setAttrib('class', 'users-form')
                ->removeDecorator('Errors');
        foreach ($valeurs as $valeur) {
            $qte->addMultiOption($valeur['id'], $valeur['valeur']);
        }



        $submit = new Zend_Form_Element_Submit('Modifier');
        $submit->setAttrib('commande', 'Modifier')
                ->setAttrib('class', 'gestion-btn');


        $this->addElements(array($id_commande, $id_produit, $date_liv_souhaite, $adresse_livraison, $ville_livraison, $cp_livraison, $adresse_facturation, $ville_facturation, $cp_facturation, $qte, $submit));
        $this->setMethod('post');
    }

}
