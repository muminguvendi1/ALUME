<?php

class Application_Form_Supprimer extends Zend_Form {

    public function init() {
        $this->setName('produit');

        $description_produit = new Zend_Form_Element_Text('description_produit');
        $description_produit->setLabel('Description')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $designation_produit = new Zend_Form_Element_Text('designation_produit');
        $designation_produit->setLabel('Designation')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $prix_produit = new Zend_Form_Element_Text('prix_produit');
        $prix_produit->setLabel('Prix Unitaire')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $tva_produit = new Zend_Form_Element_Text('tva_produit');
        $tva_produit->setLabel('TVA')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $quantite_stock = new Zend_Form_Element_Text('quantite_stock');
        $quantite_stock->setLabel('Quantite')
                ->setRequired(true)
                ->addValidator('Int', true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $id_categorie = new Zend_Form_Element_Select('id_categorie');
        $id_categorie->setLabel('Famille')
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);

        $fproduit = new Application_Model_DbTable_Categorie();
        $lstFamille = $fproduit->fetchAll();

        foreach ($lstFamille as $fp) :
            $id_categorie->addMultiOption($fp->id_categorie, $fp->description_categorie);
        endforeach;

        $submit = new Zend_Form_Element_Submit('ajouter');
        $submit->setAttrib('id_produit', 'ajouter')
                ->setAttrib('class', 'gestion-btn');


        $this->addElements(array($designation_produit, $prix_produit, $tva_produit, $description_produit, $quantite_stock, $id_categorie, $submit));
    }

}
