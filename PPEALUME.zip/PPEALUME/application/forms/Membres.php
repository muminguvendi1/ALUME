<?php

class Application_Form_Membres extends Zend_Form {

    public function __construct($options = null) {
        parent::__construct($options);

        $this->setName('Connexion');

        $nom_utilisateur = new Zend_Form_Element_Text('nom_utilisateur');
        $nom_utilisateur->setLabel("Nom d'utilisateur")
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-Z0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Nom d'utilisateur");

        $mot_de_passe = new Zend_Form_Element_Password('mot_de_passe');
        $mot_de_passe->setLabel('Mot de passe')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', 'Mot de passe');

        $connexion = new Zend_Form_Element_Submit('Connexion');
        $connexion->setLabel('Connexion')
                ->setAttrib('class', 'form-btn');

        $this->addElements(array($nom_utilisateur, $mot_de_passe, $connexion));
        $this->setMethod('post');
        $this->setAction(zend_controller_front::getInstance()->getBaseUrl() . '/authentication/connexion');
    }

}
