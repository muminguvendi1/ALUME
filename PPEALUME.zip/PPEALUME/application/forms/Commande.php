<?php

class Application_Form_Commande extends Zend_Form {

    public function init() {


        $date_livraison = new Zend_Form_Element_Text('date_liv_souhaite');
        $date_livraison->setLabel('Date de livraison souhaitée')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('placeholder', 'AAAA-MM-JJ')
                ->addValidator('regex', true, array('/^\d{4}\-\d{2}\-\d{2}$/'))
                ->addErrorMessage("Saisie incorrecte");


        $adresse_livraison = new Zend_Form_Element_Text('adresse_livraison');
        $adresse_livraison->setLabel('Adresse de livraison')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[0-9a-zA-ZÀ-ú]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->setAttrib('placeholder', "Adresse de livraison")
                ->addErrorMessage("Saisie incorrecte");

        $ville_livraison = new Zend_Form_Element_Text('ville_livraison');
        $ville_livraison->setLabel('Ville de livraison')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[a-zA-ZÀ-ú]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->setAttrib('placeholder', "Ville de livraison")
                ->addErrorMessage("Saisie incorrecte");

        $cp_livraison = new Zend_Form_Element_Text('cp_livraison');
        $cp_livraison->setLabel('CP de livraison')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[(a-zA-Z0-9)]+$/'))
                ->setAttrib('placeholder', "Code postal")
                ->addErrorMessage("Saisie incorrecte");

        $adresse_facturation = new Zend_Form_Element_Text('adresse_facturation');
        $adresse_facturation->setLabel('Adresse de facturation')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[0-9a-zA-ZÀ-ú]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->setAttrib('placeholder', "Adresse de facturation")
                ->addErrorMessage("Saisie incorrecte");

        $ville_facturation = new Zend_Form_Element_Text('ville_facturation');
        $ville_facturation->setLabel('Ville de facturation')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[a-zA-ZÀ-ú]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->setAttrib('placeholder', "Ville de facturation")
                ->addErrorMessage("Saisie incorrecte");

        $cp_facturation = new Zend_Form_Element_Text('cp_facturation');
        $cp_facturation->setLabel('CP de facturation')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[(a-zA-Z0-9)]+$/'))
                ->setAttrib('placeholder', "Code postal")
                ->addErrorMessage("Saisie incorrecte");

        $commander = new Zend_Form_Element_Submit('Commander');
        $commander->setAttrib('class', 'form-btn');


        $this->addElements(array($date_livraison, $adresse_livraison, $ville_livraison, $cp_livraison, $adresse_facturation, $ville_facturation, $cp_facturation, $commander));
        $this->setMethod('post');
    }

}
