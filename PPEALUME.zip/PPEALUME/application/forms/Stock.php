<?php

class Application_Form_Stock extends Zend_Form {

    public function init() {
        $this->setName('stock');

        $date_stock = new Zend_Form_Element_Text('date_stock');
        $date_stock->setLabel('Date Stock')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('placeholder', 'AAAA-MM-JJ')
                ->addValidator('regex', true, array('/^\d{4}\-\d{2}\-\d{2}$/'))
                ->addErrorMessage("Saisie incorrecte");

        $quantite = new Zend_Form_Element_Text('quantite_stock');
        $quantite->setLabel('Quantité')
                ->setRequired(true)
                ->addValidator('Int', true)
                ->addValidator('regex', true, array('/^[(0-9)]+$/'))
                ->setAttrib('class', 'gestion-form')
                ->addErrorMessage("Saisie incorrecte");

        $id_fournisseur = new Zend_Form_Element_Select('id_fournisseur');
        $id_fournisseur->setLabel('Fournisseur')
                ->setAttrib('class', 'gestion-form')
                ->setRequired(true)
                ->addErrorMessage("Vous n'avez pas de fournisseur");

        $fournisseur = new Application_Model_DbTable_Fournisseur();
        $lstFournisseur = $fournisseur->selectAllFournisseur();



        foreach ($lstFournisseur as $fp) :
            $id_fournisseur->addMultiOption($fp['id_fournisseur'], $fp['nom_societe']);
        
        endforeach;


        $submit = new Zend_Form_Element_Submit('Stocker');
        $submit->setAttrib('id_produit', 'modifier')
                ->setAttrib('class', 'gestion-btn');


        $this->addElements(array($date_stock, $quantite, $id_fournisseur, $submit));
    }

}

?>