<?php

class Application_Form_InscriptionParticulier extends Zend_Form {

    public function __construct($options = null) {
        parent::__construct($options);

        $this->setName('InscriptionPart');

        $nom_utilisateur = new Zend_Form_Element_Text('nom_utilisateur');
        $nom_utilisateur->setLabel("Nom d'utilisateur")
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-Z0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Nom d'utilisateur");


        $mot_de_passe = new Zend_Form_Element_Password('mot_de_passe');
        $mot_de_passe->setLabel('Mot de passe')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', 'Mot de passe');



        $nom = new Zend_Form_Element_Text('nom');
        $nom->setLabel("Nom")
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Nom de l'utilisateur");



        $prenom = new Zend_Form_Element_Text('prenom');
        $prenom->setLabel('Prenom')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Prenom de l'utilisateur");

        $date_naissance = new Zend_Form_Element_Text('date_naissance');
        $date_naissance->setLabel('Date de naissance')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->setAttrib('placeholder', 'AAAA-MM-JJ')
                ->addValidator('regex', true, array('/^\d{4}\-\d{2}\-\d{2}$/'))
                ->addErrorMessage("Saisie incorrecte");

        $valeurs = array(array('id' => 'HOMME', 'valeur' => 'HOMME'),
            array('id' => 'FEMME', 'valeur' => 'FEMME')
        );

        $sexe = $this->createElement('select', 'sexe');
        $sexe->setLabel('Sexe')
                ->setAttrib('class', 'users-form')
                ->removeDecorator('Errors');
        foreach ($valeurs as $valeur) {
            $sexe->addMultiOption($valeur['id'], $valeur['valeur']);
        }


        $adresse = new Zend_Form_Element_Text('adresse');
        $adresse->setLabel('Adresse')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[0-9a-zA-ZÀ-ú]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Adresse de l'uitilisateur");


        $ville = new Zend_Form_Element_Text('ville');
        $ville->setLabel('Ville')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[a-zA-ZÀ-ú]{1}[a-zA-Z 0-9 -]*$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Ville de l'utilisateur");


        $code_postal = new Zend_Form_Element_Text('code_postal');
        $code_postal->setLabel('Code postal')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addFilter(new Zend_Filter_StringTrim())
                ->addValidator('regex', true, array('/^[(a-zA-Z0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Code postal de l'utilisateur");


        $email_client = new Zend_Form_Element_Text('email');
        $email_client->setLabel('E-mail')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->setAttrib('placeholder', "Adresse mail de l'utilisateur")
            ->addFilters(array('StringTrim', 'StripTags'))
            ->addValidator('EmailAddress',  TRUE  )
                ->addErrorMessage("Email incorrect");


        $tel_client = new Zend_Form_Element_Text('tel');
        $tel_client->setLabel('Telephone')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->setAttrib('placeholder', 'N° de téléphone')
                ->addValidator('regex', true, array('/^[(0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte");




        $inscription = new Zend_Form_Element_Submit('inscription');
        $inscription->setLabel('Inscription')
                ->setAttrib('class', 'form-btn');


        $this->addElements(array($nom_utilisateur, $mot_de_passe, $nom, $prenom, $date_naissance, $sexe, $adresse, $ville, $code_postal, $email_client, $tel_client, $inscription));
        $this->setMethod('post');
        $this->setAction(zend_controller_front::getInstance()->getBaseUrl() . '/membres/inscription');
    }

}
