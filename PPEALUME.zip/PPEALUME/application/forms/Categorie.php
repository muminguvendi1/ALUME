<?php

class Application_Form_Categorie extends Zend_Form {

    public function init() {
        $this->setName('categorie');

        $description_categorie = new Zend_Form_Element_Text('description_categorie');
        $description_categorie->setLabel('Catégorie du produit')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Désignation");

        $submit = new Zend_Form_Element_Submit('ajouter');
        $submit->setAttrib('description_categorie', 'ajouter')
                ->setAttrib('class', 'gestion-btn');

        $this->addElements(array($description_categorie, $submit));
    }

}
