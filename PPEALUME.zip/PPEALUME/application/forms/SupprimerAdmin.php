<?php

class Application_Form_SupprimerAdmin extends Zend_Form
{

    public function init() {

        $nom_utilisateur = new Zend_Form_Element_Text('nom_utilisateur');
        $nom_utilisateur->setLabel("Nom utilisateur")
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('disabled', TRUE);


        $submit = new Zend_Form_Element_Submit('Supprimer');
        $submit->setAttrib('commande', 'Supprimer')
                ->setAttrib('class', 'gestion-btn');


        $this->addElements(array($nom_utilisateur,$submit));
        $this->setMethod('post');
    }


}

