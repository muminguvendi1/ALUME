<?php

class Application_Form_Produit extends Zend_Form {

    public function init() {
        $this->setName('produit');

        $photo_produit = new Zend_Form_Element_Text('photo_produit');
        $photo_produit->setLabel('Designation photo')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('placeholder', 'image.jpg')
                ->addErrorMessage("Saisie incorrecte");

        $description_produit = new Zend_Form_Element_Text('description_produit');
        $description_produit->setLabel('Description')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('placeholder', 'Description du produit')
                ->addErrorMessage("Saisie incorrecte");

        $designation_produit = new Zend_Form_Element_Text('designation_produit');
        $designation_produit->setLabel('Designation')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('placeholder', 'Désignation du produit')
                ->addErrorMessage("Saisie incorrecte");

        $prix_produit = new Zend_Form_Element_Text('prix_produit');
        $prix_produit->setLabel('Prix Unitaire HT')
                ->setRequired(true)
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('placeholder', 'Prix HT €, Ex : 12.2')
                ->addValidator(new Zend_Validate_Float('en_US'))
                ->addErrorMessage("Saisie incorrecte");



        $quantite_stock = new Zend_Form_Element_Text('quantite_stock');
        $quantite_stock->setLabel('Quantite')
                ->setRequired(true)
                ->addValidator('Int', true)
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[(0-9)]+$/'))
                ->setAttrib('placeholder', 'Quantité')
                ->addErrorMessage("Saisie incorrecte");

        $id_categorie = new Zend_Form_Element_Select('id_categorie');
        $id_categorie->setLabel('Type')
                ->setAttrib('class', 'gestion-form')
                ->setRequired(true)
                ->addErrorMessage("Ajoutez d'abord le type de produit");


        $id_fournisseur = new Zend_Form_Element_Select('id_fournisseur');
        $id_fournisseur->setLabel('Fournisseur')
                ->setAttrib('class', 'gestion-form')
                ->setRequired(true)
                ->addErrorMessage("Ajoutez d'abord le fournisseur");

        $fproduit = new Application_Model_DbTable_Categorie();
        $lstFamille = $fproduit->selectAllCategorie();

        $fournisseur = new Application_Model_DbTable_Fournisseur();
        $lstFournisseur = $fournisseur->selectAllFournisseur();

        foreach ($lstFamille as $fp) :
            $id_categorie->addMultiOption($fp['id_categorie'], $fp['description_categorie']);
        endforeach;

        foreach ($lstFournisseur as $fp) :
            $id_fournisseur->addMultiOption($fp['id_fournisseur'], $fp['nom_societe']);
        endforeach;

        $submit = new Zend_Form_Element_Submit('ajouter');
        $submit->setAttrib('id_produit', 'ajouter')
                ->setAttrib('class', 'gestion-btn');


        $this->addElements(array($photo_produit, $designation_produit, $prix_produit, $description_produit, $quantite_stock, $id_categorie, $id_fournisseur, $submit));
    }

}
