<?php

class Application_Form_UpdateProfilAdmin extends Zend_Form {

    public function init() {

        $nom_utilisateur = new Zend_Form_Element_Text('nom_utilisateur');
        $nom_utilisateur->setLabel("Nom utilisateur")
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addValidator('regex', true, array('/^[(a-zA-Z0-9)]+$/'))
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', "Nom d'utilisateur");

        $mot_de_passe = new Zend_Form_Element_Password('mot_de_passe');
        $mot_de_passe->setLabel('Mot de passe')
                ->setRequired(true)
                ->setAttrib('class', 'users-form')
                ->addErrorMessage("Saisie incorrecte")
                ->setAttrib('placeholder', 'Mot de passe');

        $submit = new Zend_Form_Element_Submit('Modifier');
        $submit->setAttrib('commande', 'Modifier')
                ->setAttrib('class', 'gestion-btn');

        $this->addElements(array($nom_utilisateur, $mot_de_passe, $submit));
        $this->setMethod('post');
    }

}
