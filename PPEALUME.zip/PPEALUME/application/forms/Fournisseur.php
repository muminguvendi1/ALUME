<?php

class Application_Form_Fournisseur extends Zend_Form {

    public function init() {
        $this->setName('fournisseur');

        $nom_societe = new Zend_Form_Element_Text('nom_societe');
        $nom_societe->setLabel('Nom de la societe')
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú 0-9)]+$/'))
                ->setAttrib('placeholder', "Nom de societé")
                ->addErrorMessage("Saisie incorrecte");

        $nom_contact = new Zend_Form_Element_Text('nom_contact');
        $nom_contact->setLabel('Nom contact')
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú)]+$/'))
                ->setAttrib('placeholder', "Nom du contact")
                ->addErrorMessage("Saisie incorrecte");


        $prenom_contact = new Zend_Form_Element_Text('prenom_contact');
        $prenom_contact->setLabel('Prenom contact')
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[(a-zA-ZÀ-ú)]+$/'))
                ->setAttrib('placeholder', "Prenom du contact")
                ->addErrorMessage("Saisie incorrecte");

        $tel_contact = new Zend_Form_Element_Text('tel_contact');
        $tel_contact->setLabel('N° Tel')
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[(0-9)]+$/'))
                ->setAttrib('placeholder', "Numéro de telephone")
                ->addErrorMessage("Saisie incorrecte");

        $adresse_fournisseur = new Zend_Form_Element_Text('adresse_fournisseur');
        $adresse_fournisseur->setLabel('Adresse')
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[0-9a-zA-ZÀ-ú]{1}[a-zA-Z 0-9 -]*$/'))
                ->setAttrib('placeholder', "Adresse du fournisseur")
                ->addErrorMessage("Saisie incorrecte");


        $ville_fournisseur = new Zend_Form_Element_Text('ville_fournisseur');
        $ville_fournisseur->setLabel('Ville')
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[a-zA-ZÀ-ú]{1}[a-zA-ZÀ-ú 0-9 -]*$/'))
                ->setAttrib('placeholder', "Ville du fourniseur")
                ->addErrorMessage("Saisie incorrecte");

        $CP_fournisseur = new Zend_Form_Element_Text('CP_fournisseur');
        $CP_fournisseur->setLabel('Code postal')
                ->setAttrib('class', 'gestion-form')
                ->addValidator('regex', true, array('/^[(a-zA-Z 0-9)]+$/'))
                ->setAttrib('placeholder', "Code postal du fournisseur")
                ->addErrorMessage("Saisie incorrecte");

        $submit = new Zend_Form_Element_Submit('Ajouter');
        $submit->setAttrib('id_fournisseur', 'Ajouter')
                ->setAttrib('class', 'gestion-btn');


        $this->addElements(array($nom_societe, $nom_contact, $prenom_contact, $prenom_contact, $tel_contact, $adresse_fournisseur, $ville_fournisseur, $CP_fournisseur, $submit));
        $this->setMethod('post');
    }
}
