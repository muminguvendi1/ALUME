<?php

class Application_Form_SupprimerLigneCommande extends Zend_Form {

    public function __construct($options = null) {
        parent::__construct($options);


        $id_commande = new Zend_Form_Element_Text('id_commande');
        $id_commande->setLabel("N° de commande")
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('readonly', 'readonly');

        $id_produit = new Zend_Form_Element_Text('id_produit');
        $id_produit->setLabel("N° de produit")
                ->setAttrib('class', 'gestion-form')
                ->setAttrib('readonly', 'readonly');

        $date_liv_souhaite = new Zend_Form_Element_Text('date_liv_souhaite');
        $date_liv_souhaite->setLabel('Date de livraison souhaitée')
                ->setAttrib('class', 'users-form')
                ->setAttrib('readonly', 'readonly');

        $adresse_livraison = new Zend_Form_Element_Text('adresse_livraison');
        $adresse_livraison->setLabel('Adresse de livraison')
                ->setAttrib('class', 'users-form')
                ->setAttrib('readonly', 'readonly');

        $ville_livraison = new Zend_Form_Element_Text('ville_livraison');
        $ville_livraison->setLabel('Ville de livraison')
                ->setAttrib('class', 'users-form')
                ->setAttrib('readonly', 'readonly');

        $cp_livraison = new Zend_Form_Element_Text('cp_livraison');
        $cp_livraison->setLabel('Code postal de livraison')
                ->setAttrib('class', 'users-form')
                ->setAttrib('readonly', 'readonly');

        $adresse_facturation = new Zend_Form_Element_Text('adresse_facturation');
        $adresse_facturation->setLabel('Adresse de facturation')
                ->setAttrib('class', 'users-form')
                ->setAttrib('readonly', 'readonly');

        $ville_facturation = new Zend_Form_Element_Text('ville_facturation');
        $ville_facturation->setLabel('Ville de facturation')
                ->setAttrib('class', 'users-form')
                ->setAttrib('readonly', 'readonly');

        $cp_facturation = new Zend_Form_Element_Text('cp_facturation');
        $cp_facturation->setLabel('Code postal de facturation')
                ->setAttrib('class', 'users-form')
                ->setAttrib('readonly', 'readonly');

        $valeurs = array(array('id' => '1', 'valeur' => '1'),
            array('id' => '2', 'valeur' => '2'),
            array('id' => '3', 'valeur' => '3'),
            array('id' => '4', 'valeur' => '4'),
            array('id' => '5', 'valeur' => '5'),
            array('id' => '6', 'valeur' => '6'),
            array('id' => '7', 'valeur' => '7'),
            array('id' => '8', 'valeur' => '8'),
            array('id' => '9', 'valeur' => '9'),
            array('id' => '10', 'valeur' => '10')
        );

        $qte = $this->createElement('select', 'quantite_commande');
        $qte->setLabel('Quantité')
                ->setAttrib('class', 'users-form')
                ->removeDecorator('Errors')
                ->setAttrib('readonly', 'readonly')
                ->setAttrib('disabled', TRUE);

        foreach ($valeurs as $valeur) {
            $qte->addMultiOption($valeur['id'], $valeur['valeur']);
        }

        $submit = new Zend_Form_Element_Submit('Supprimer');
        $submit->setAttrib('commande', 'Supprimer')
                ->setAttrib('class', 'gestion-btn');

        $this->addElements(array($id_commande, $id_produit, $date_liv_souhaite, $adresse_livraison, $ville_livraison, $cp_livraison, $adresse_facturation, $ville_facturation, $cp_facturation, $qte, $submit));
    }

}
