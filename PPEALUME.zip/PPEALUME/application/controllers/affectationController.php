<?php

class affectationController extends Zend_Controller_Action {

    //Verif si connecté, sinon redirection
    public function init() {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
        } else
        {
           $this->_helper->redirector('connexion', 'authentication');
        }
    }

    public function indexAction() {
        $client = new Application_Model_DbTable_Utilisateur();
        $this->view->affecter = $client->selectAllClientRepresentant();
    }

    public function ajouterAction() {
        //Instanciation de form
        $form = new Application_Form_Affectation();
        //afficher form
        $this->view->form = $form;
        /* si isPost() de l'objet de requete envoie true, alors le formulaire a été envoyé.
         * récupération des données de la raquete avec la methode getpost() dans $formData
         * véfification de leurs validité avec la méthode membre isValid() */

        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                //récupération des données des elements du form
                $id_utilisateur = $form->getValue('id_utilisateur');
                $id_representant = $form->getValue('id_representant');

                //l'instanciation table Professionnel
                $fournisseur = new Application_Model_DbTable_Professionnel();
                $fournisseur->affecterClient($id_utilisateur, $id_representant);
                //rédirection vers une action de controleur courant
                $this->_helper->redirector('index');
            } else {
                /* si l'une des données de formulaire n'est pas valide le controleur retourne
                 * la meme vue, et pour ne pas perdre les données on rempli les composants avec les données 
                 * fournies
                 */
                $form->populate($formData);
            }
        }
    }

    public function modifierAction() {
        //Récuperation du param URL
        $id_utilisateur = $this->_getParam('id_utilisateur', 0);
        //Instanciation du fom et affichage dans la vue
        $form = new Application_Form_ModifierAffectation();
        $this->view->form = $form;
        //Vérif validité des valeurs -> recupération des valeurs
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $id_representant = $form->getValue('id_representant');
                //Appel de la fonction modifierClient de la table profesisonnel
                $client = new Application_Model_DbTable_Professionnel();
                $client->modifierClient($id_utilisateur, $id_representant);
                //Redirection a l'index
                $this->_helper->redirector('index');
            } else {
                $form->populate($formData);
            }
        } else {
            /* Si l'id existe et sa valeur est supérieure a la valeur d'initialisation, on le 
             * recupere et on rempli les champs des formulaires par les données du produit
             * par la methode populate(array)
             */
            if ($id_utilisateur > 0) {
                $client = new Application_Model_DbTable_Utilisateur();
                $pdt = $client->rechercherClient($id_utilisateur);
                //selection de la famille de produit
                $form->populate($pdt);
            }
        }
    }
}
