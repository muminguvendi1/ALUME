<?php

class adminController extends Zend_Controller_Action {

    //La fonction init est éxécute dans tout les cas, si on n'est pas connecté il faut se connecter.
    //Pas de controle admin/user car les ACL le font déja.
    public function init() {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
        } else
            $this->_helper->redirector('connexion', 'authentication');
    }

    //Affichage du contenu de la table admin dans la vue Admin->index
    public function indexAction() {
        $admin = new Application_Model_DbTable_Admin();
        $this->view->lstAdmin = $admin->fetchAll();
    }

    public function modifierAction() {
        //Je recupere l'id passé en paramètre
        $id_admin = $this->_getParam('id_admin', 0);
        //Appel du formulaire de MAJ
        $form = new Application_Form_UpdateProfilAdmin();
        $this->view->form = $form;
        // Si le formulaire est bien remplis
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                //Récupération des champs du form
                $nom_utilisateur = $form->getValue('nom_utilisateur');
                $mot_de_passe = $form->getValue('mot_de_passe');
                //Instanciation de la table Admin
                $admin = new Application_Model_DbTable_Admin();
                // Appel de la fonction + envoi des params
                $admin->majAdmin($id_admin, $nom_utilisateur, $mot_de_passe);
                // Redirection a l'index du controlleur
                $this->_helper->redirector('index');
            } else {
                // Sinon on reaffiche le fom avec les valeurs correctes
                $form->populate($formData);
            }
        } else {
            /* Si l'id existe et sa valeur est supérieure a la valeur d'initialisation, on le 
             * recupere et on rempli les champs des formulaires par les données recup
             * par la methode populate(array)
             */
            if ($id_admin > 0) {
                $admin = new Application_Model_DbTable_Admin();
                $pdt = $admin->rechercherAdmin($id_admin);
                //selection des params de l'admin
                $form->populate($pdt);
            }
        }
    }

    public function supprimerAction() {
        //Appel du form
        $form = new Application_Form_SupprimerAdmin();
        //Envoi du form vers la vue
        $this->view->form = $form;
        // Récup param de l'URL
        $id_admin = $this->_getParam('id_admin', 0);
        if ($this->getRequest()->isPost()) {
            $admin = new Application_Model_DbTable_Admin();
            $admin->supprimerAdmin($id_admin);
            //Redirection
            $this->_helper->redirector('index');
        } else {
            if ($id_admin > 0) {
                // Récup des param pour remplir le form
                $commande = new Application_Model_DbTable_Admin();
                $c = $commande->rechercherAdmin($id_admin);
                //Populate sert a remplir le form
                $form->populate($c);
            }
        }
    }

    public function ajouterAction() {
        //Instanciation de form
        $form = new Application_Form_AjoutAdmin();
        //afficher form
        $this->view->form = $form;

        /* si isPost() de l'objet de requete envoie true, alors le formulaire a été envoyé.
         * récupération des données de la raquete avec la methode getpost() dans $formData
         * véfification de leurs validité avec la méthode membre isValid() */

        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                //récupération des données des elements du form
                $nom_utilisateur = $form->getValue('nom_utilisateur');
                $mot_de_passe = $form->getValue('mot_de_passe');
                //l'instanciation des données par la méthode ajouterProduit()
                $admin = new Application_Model_DbTable_Admin();
                // l'insération des données par la méthode ajouterProduit()
                $admin->ajouter($nom_utilisateur, $mot_de_passe);
                //rédirection vers une action de controleur courant
                $this->_helper->redirector('index');
            } else {
                /* si l'une des données de formulaire n'est pas valide le controleur retourne
                 * la meme vue, et pour ne pas perdre les données on rempli les composants avec les données 
                 * fournies
                 */
                $form->populate($formData);
            }
        }
    }

}
