<?php

class membresController extends Zend_Controller_Action {

    protected $cacheHandler = null;

    //On récupere le contenu du cache
    public function init() {
        $this->cacheHandler = new Application_Model_CacheHandler();
    }

    public function indexAction() {
        //Si l'utilisateur est connecté, on récupere son role
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            $identify = $auth->getStorage()->read();
            $role = $identify->role;
            //Selon son role, on récupere son identifiant (id_admin ou id_utilisateur)
            if ($role != 'admin') {
                $id_utilisateur = $auth->getIdentity()->id_utilisateur;
            }
            //Si c'est un administrateur, on le redirige vers son profil car un admin ne passe pas de commandes. 
            if ($role == 'admin') {
                $this->_helper->redirector('profil');
            } else {
                //Sinon c'est un user, donc on affiche ses commandes
                $commande = new Application_Model_DbTable_Commande();
                $this->view->commande = $commande->commandes($id_utilisateur);
            }
        } else {
            $this->_helper->redirector('connexion', 'authentication');
        }
        //On affiche le nb d'article dans le panier
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

    public function profilAction() {

        //On récupere le role de l'utilisateur connecté ainsi que son id
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            $identify = $auth->getStorage()->read();
            $role = $identify->role;

            if ($role == 'admin') {
                $id_admin = $auth->getIdentity()->id_admin;
                $id_utilisateur = null;
            } else {
                $id_utilisateur = $auth->getIdentity()->id_utilisateur;
                $id_admin = null;
            }

            // Si c'est un admin, on affiche le formulaire admin
            if ($id_admin != null) {
                $form = new Application_Form_UpdateProfilAdmin();
                $this->view->formProfil = $form;
                //Si le formulaire est envoyé, on vérifie s'il est valide et on récupere les valeurs
                if ($this->getRequest()->isPost()) {
                    $formData = $this->getRequest()->getPost();
                    if ($form->isValid($formData)) {
                        $mot_de_passe = $form->getValue('mot_de_passe');
                        $nom_utilisateur = $form->getValue('nom_utilisateur');

                        $administrateur = new Application_Model_DbTable_Admin();
                        $administrateur->majAdmin($id_admin, $nom_utilisateur, $mot_de_passe);
                        $this->_helper->redirector('index', 'produit');
                    }
                } else if ($id_admin > 0) {
                    //Sinon on va chercher les parametres de l'admin pour pré-remplir le form avec ses données
                    $admin = new Application_Model_DbTable_Admin();
                    $valeur = $admin->verifUser($id_admin);

                    $form->populate($valeur);
                }
            } else if ($id_utilisateur != null) {
                //On controle si l'utilisateur est particulier ou professionnel
                $updatePart = new Application_Model_DbTable_Particulier();
                $particulier = $updatePart->recherche($id_utilisateur);

                $updatePro = new Application_Model_DbTable_Professionnel();
                $professionnel = $updatePro->recherche($id_utilisateur);
                //S'il est particulier on affiche le form particulier
                if ($particulier != null) {
                    $form = new Application_Form_UpdateProfilParticulier;
                    $this->view->formProfil = $form;

                    //On vérifie si le form est envoyé et si les valeurs sont valides et on récupere les valeurs.
                    if ($this->getRequest()->isPost()) {
                        $formData = $this->getRequest()->getPost();
                        if ($form->isValid($formData)) {

                            $mot_de_passe = $form->getValue('mot_de_passe');
                            $nom = $form->getValue('nom');
                            $prenom = $form->getValue('prenom');
                            $date_naissance = $form->getValue('date_naissance');
                            $sexe = $form->getValue('sexe');
                            $adresse = $form->getValue('adresse');
                            $ville = $form->getValue('ville');
                            $code_postal = $form->getValue('code_postal');
                            $email = $form->getValue('email');
                            $tel = $form->getValue('tel');
                            //Appel de la fonction avec envoi des params
                            $pro = new Application_Model_DbTable_Utilisateur();
                            $pro->majProfil($mot_de_passe, $nom, $prenom, $adresse, $ville, $code_postal, $email, $tel, $id_utilisateur);
                            $updatePart->majHeritage($date_naissance, $sexe, $id_utilisateur);
                            $this->_helper->redirector('index');
                        }
                    } else if ($particulier == true) {
                        //Si l'utilisateur est un particulier, on va récuperer les valeurs dans la table utilisateur et particulier pour remplir le form
                        $part = new Application_Model_DbTable_Utilisateur();
                        $val = $part->rechercherClient($id_utilisateur);

                        $particulier = new Application_Model_DbTable_Particulier();
                        $valeur = $particulier->getParam($id_utilisateur);

                        $form->populate($val);
                        $form->populate($valeur);
                    }
                } else if ($professionnel != null) {
                    //Si c'est un professionnel, on charge le formulaire professionnel.
                    $form = new Application_Form_UpdateProfilProfessionnel;
                    $this->view->formProfil = $form;
                    //Vérif si le fom est envoyé et vérif s'il est valid
                    if ($this->getRequest()->isPost()) {
                        $formData = $this->getRequest()->getPost();
                        if ($form->isValid($formData)) {

                            $mot_de_passe = $form->getValue('mot_de_passe');
                            $nom = $form->getValue('nom');
                            $prenom = $form->getValue('prenom');
                            $adresse = $form->getValue('adresse');
                            $ville = $form->getValue('ville');
                            $code_postal = $form->getValue('code_postal');
                            $email = $form->getValue('email');
                            $tel = $form->getValue('tel');
                            $activite = $form->getValue('activite');
                            $raison_sociale = $form->getValue('raison_sociale');
                            $numero_siret = $form->getValue('numero_siret');

                            $pro = new Application_Model_DbTable_Utilisateur();
                            $pro->majProfil($mot_de_passe, $nom, $prenom, $adresse, $ville, $code_postal, $email, $tel, $id_utilisateur);
                            $updatePro->majHeritage($activite, $raison_sociale, $numero_siret, $id_utilisateur);
                            $this->_helper->redirector('index');
                        }
                    } else if ($professionnel == true) {
                        //On récupere les valeurs de l'utilisateur pour remplir le formulaire
                        $pro = new Application_Model_DbTable_Utilisateur();
                        $val = $pro->rechercherClient($id_utilisateur);

                        $professionnel = new Application_Model_DbTable_Professionnel();
                        $valeur = $professionnel->getParam($id_utilisateur);

                        $form->populate($val);
                        $form->populate($valeur);
                    }
                }
            } else {
                echo "Bonjour, votre profil est pour le moment non modifiable, veuillez contacter votre administrateur.";
            }
        } else {
            $this->_helper->redirector('connexion', 'authentication');
        }
        //On affiche le nb d'article dans le panier
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

    public function inscriptionAction() {
        //Affichage du form dans la vue
        $form = new Application_Form_InscriptionParticulier();
        $this->view->formPart = $form;

        //Véfifications : envoi - validité
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();

            if ($form->isValid($formData)) {
                $nom_utilisateur = $form->getValue('nom_utilisateur');
                $mot_de_passe = $form->getValue('mot_de_passe');
                $nom = $form->getValue('nom');
                $prenom = $form->getValue('prenom');
                $adresse = $form->getValue('adresse');
                $ville = $form->getValue('ville');
                $code_postal = $form->getValue('code_postal');
                $email = $form->getValue('email');
                $tel = $form->getValue('tel');
                $date_naissance = $form->getValue('date_naissance');
                $sexe = $form->getValue('sexe');

                //On envoie les parametres pour les insérer dans les tables
                $inscription = new Application_Model_DbTable_Utilisateur();
                $inscription->ajouter($nom_utilisateur, $mot_de_passe, $nom, $prenom, $adresse, $ville, $code_postal, $tel, $email);

                $heritageParticulier = new Application_Model_DbTable_Particulier();
                $heritageParticulier->heritage($date_naissance, $sexe);
                $this->_redirect('index');
            }
        }
        //On affiche le nb d'article dans le panier
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

    public function professionnelAction() {
        //Affichage du form
        $form = new Application_Form_InscriptionProfessionnel();
        $this->view->formPro = $form;
        //On véfifie si le fomulaire est envoyé et si les valeurs sont valides
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();

            if ($form->isValid($formData)) {
                $nom_utilisateur = $form->getValue('nom_utilisateur');
                $mot_de_passe = $form->getValue('mot_de_passe');
                $nom = $form->getValue('nom');
                $prenom = $form->getValue('prenom');
                $adresse = $form->getValue('adresse');
                $ville = $form->getValue('ville');
                $code_postal = $form->getValue('code_postal');
                $email = $form->getValue('email');
                $tel = $form->getValue('tel');
                $activite = $form->getValue('activite');
                $raison_sociale = $form->getValue('raison_sociale');
                $numero_siret = $form->getValue('numero_siret');

                //Envoi des params pour insertion dans les tables.
                $inscription = new Application_Model_DbTable_Utilisateur();
                $inscription->ajouter($nom_utilisateur, $mot_de_passe, $nom, $prenom, $adresse, $ville, $code_postal, $tel, $email);

                $heritageParticulier = new Application_Model_DbTable_Professionnel();
                $heritageParticulier->heritage($activite, $raison_sociale, $numero_siret);
                $this->_redirect('index');
            }
        }
        //On affiche le nb d'article dans le panier
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

    public function factureAction() {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            //On désactive le layout dans le PDF
            $this->_helper->viewRenderer->setNoRender(true);
            $this->_helper->layout->disableLayout();

            //Récupération du parametre envoyé par URL et récupération de l'ID utilisateur
            $id_commande = $this->_getParam('id_commande', 0);
            $auth = Zend_Auth::getInstance();
            if ($auth->hasIdentity()) {
                $id_utilisateur = $auth->getIdentity()->id_utilisateur;
            }

            //On vérifie que l'id de commande appartient a l'utilisateur connecté.
            $verifCommande = new Application_Model_DbTable_Commande();
            $count = $verifCommande->verifUserCommande($id_commande, $id_utilisateur);
            // On fais appel au pdf
            if ($count == 1) {
                require("sql_to_pdf/PDF.php");
            } else {
                $this->_redirect('membres/index');
            }
        } else {
            $this->_helper->redirector('connexion', 'authentication');
        }
    }

}
