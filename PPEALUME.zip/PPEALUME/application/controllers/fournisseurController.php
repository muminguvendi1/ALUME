<?php

class fournisseurController extends Zend_Controller_Action {

    public function init() {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            
        } else
            $this->_helper->redirector('connexion', 'authentication');
    }

    public function indexAction() {
        //On affiche tout les fournisseurs
        $fournisseur = new Application_Model_DbTable_Fournisseur();
        $this->view->lstPdt = $fournisseur->selectAllFournisseur();

        $fournisseur = new Application_Model_DbTable_Fournisseur();
        $this->view->lstDesactive = $fournisseur->selectAllDesactive();
    }

    public function activerAction() {
        $id_fournisseur = $this->_getParam('id_fournisseur', 0);

        $fournisseur = new Application_Model_DbTable_Fournisseur();
        // l'insértion des données par la méthode ajouterFournisseur()
        $fournisseur->activerFournisseur($id_fournisseur);
        //rédirection vers une action de controleur courant
        $this->_helper->redirector('index');
    }

    public function ajouterAction() {
        //Instanciation de form
        $form = new Application_Form_Fournisseur();
        //afficher form
        $this->view->form = $form;

        /* si isPost() de l'objet de requete envoie true, alors le formulaire a été envoyé.
         * récupération des données de la raquete avec la methode getpost() dans $formData
         * véfification de leurs validité avec la méthode membre isValid() */
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                //récupération des données des elements du form
                $nom_societe = $form->getValue('nom_societe');
                $nom_contact = $form->getValue('nom_contact');
                $prenom_contact = $form->getValue('prenom_contact');
                $tel_contact = $form->getValue('tel_contact');
                $adresse_fournisseur = $form->getValue('adresse_fournisseur');
                $ville_fournisseur = $form->getValue('ville_fournisseur');
                $CP_fournisseur = $form->getValue('CP_fournisseur');

                $fournisseur = new Application_Model_DbTable_Fournisseur();
                // l'insértion des données par la méthode ajouterFournisseur()
                $fournisseur->ajouterFournisseur($nom_societe, $nom_contact, $prenom_contact, $tel_contact, $adresse_fournisseur, $ville_fournisseur, $CP_fournisseur);
                //rédirection vers une action de controleur courant
                $this->_helper->redirector('index');
            } else {
                /* si l'une des données de formulaire n'est pas valide le controleur retourne
                 * la meme vue, et pour ne pas perdre les données on rempli les composants avec les données 
                 * fournies
                 */
                $form->populate($formData);
            }
        }
    }

    public function modifierAction() {
        //Récupération du param
        $id_fournisseur = $this->_getParam('id_fournisseur', 0);
        //Instanciation de form
        $form = new Application_Form_Fournisseur();
        $form->Ajouter->setLabel('Modifier');
        $this->view->form = $form;

        /* si isPost() de l'objet de requete envoie true, alors le formulaire a été envoyé.
         * récupération des données de la raquete avec la methode getpost() dans $formData
         * véfification de leurs validité avec la méthode membre isValid() */
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $nom_societe = $form->getValue('nom_societe');
                $nom_contact = $form->getValue('nom_contact');
                $prenom_contact = $form->getValue('prenom_contact');
                $tel_contact = $form->getValue('tel_contact');
                $adresse_fournisseur = $form->getValue('adresse_fournisseur');
                $ville_fournisseur = $form->getValue('ville_fournisseur');
                $CP_fournisseur = $form->getValue('CP_fournisseur');
                //Appel de la fonction modifierFournisseur et envoi des params
                $fournisseur = new Application_Model_DbTable_Fournisseur();
                $fournisseur->modifierFournisseur($id_fournisseur, $nom_societe, $nom_contact, $prenom_contact, $tel_contact, $adresse_fournisseur, $ville_fournisseur, $CP_fournisseur);
                //Redirection vers l'index
                $this->_helper->redirector('index');
            } else {
                //Si le form n'est pas valide, on le reaffiche avec les valeurs precedentes
                $form->populate($formData);
            }
        } else {
            /* Si l'id existe et sa valeur est supérieure a la valeur d'initialisation, on le 
             * recupere et on rempli les champs des formulaires par les données recup
             * par la methode populate(array)
             */
            if ($id_fournisseur > 0) {
                $fournisseur = new Application_Model_DbTable_Fournisseur();
                $pdt = $fournisseur->rechercherFournisseur($id_fournisseur);

                $form->populate($pdt);
            }
        }
    }

    public function desactiverAction() {
        // Appel du form et affichage dans la vue
        $form = new Application_Form_SupprimerFournisseur();
        $this->view->form = $form;
        // Récupération de parametre id qui spécifie l'id du fournisseur, et on l'initialise a 0 si vide
        $id_fournisseur = $this->_getParam('id_fournisseur', 0);
        //Si le form est envoyé, on supprime le fournisseur.
        if ($this->getRequest()->isPost()) {
            $fournisseur = new Application_Model_DbTable_Fournisseur();
            $fournisseur->desactiverFournisseur($id_fournisseur);
            $this->_helper->redirector('index');
        } else {
            /* Si l'id existe et sa valeur est supérieure a la valeur d'initialisation, on le 
             * recupere et on rempli les champs des formulaires par les données recup
             * par la methode populate(array)
             */
            if ($id_fournisseur > 0) {
                $fournisseur = new Application_Model_DbTable_Fournisseur();
                $pdt = $fournisseur->rechercherFournisseur($id_fournisseur);
                $form->populate($pdt);
            }
        }
    }

}
