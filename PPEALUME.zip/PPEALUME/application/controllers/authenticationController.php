<?php

class authenticationController extends Zend_Controller_Action {

    protected $cacheHandler = null;

    //On récupere le contenu du cache
    public function init() {
        $this->cacheHandler = new Application_Model_CacheHandler();
    }

    public function indexAction() {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            $this->_helper->redirector('index', 'membres');
        } else
            $this->_helper->redirector('connexion', 'authentication');
    }

    public function adminAction() {
        //Si connecté, redirection vers l'index du controlleur Produit
        if (Zend_Auth::getInstance()->hasIdentity()) {
            $this->_redirect('produit/index');
        }
        //Affichage du form
        $request = $this->getRequest();
        $form = new Application_Form_Login();
        //Verif des valeurs
        if ($request->isPost()) {
            if ($form->isValid($this->_request->getPost())) {
                //Définition des colonnes pour verif des connexion
                $authAdapter = $this->getAuthAdapterAdmin();
                $nom_utilisateur = $form->getValue('nom_utilisateur');
                $mot_de_passe = $form->getValue('mot_de_passe');
                $authAdapter->setIdentity($nom_utilisateur)
                        ->setCredential($mot_de_passe);

                //On définit le role et envoie les params
                $role = 'administrateur';
                $verifConnect = new Application_Model_DbTable_Admin();
                $verifConnect->proSto($nom_utilisateur, $mot_de_passe, $role);

                $auth = Zend_Auth::getInstance();
                $result = $auth->authenticate($authAdapter);

                if ($result->isValid()) {
                    $identity = $authAdapter->getResultRowObject();

                    $authStorage = $auth->getStorage();
                    $authStorage->write($identity);

                    $this->_redirect('produit/index');
                } else {
                    $this->view->errorMessage = '<p style="font-family: helvetica;font-size: 16px;font-weight: bold;color: red;">Nom utilisateur ou mot de passe incorrect</p>';
                }
            }
        }
        $this->view->form = $form;
        //On affiche le nb d'article dans le panier
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

    public function connexionAction() {
        if (Zend_Auth::getInstance()->hasIdentity()) {
            $this->_redirect('membres/index');
        }

        $request = $this->getRequest();
        $formusers = new Application_Form_Membres();
        if ($request->isPost()) {
            if ($formusers->isValid($this->_request->getPost())) {
                $authAdapter = $this->getAuthAdapter();

                $nom_utilisateur = $formusers->getValue('nom_utilisateur');
                $mot_de_passe = $formusers->getValue('mot_de_passe');

                $authAdapter->setIdentity($nom_utilisateur)
                        ->setCredential($mot_de_passe);

                $role = 'user';
                $verifConnect = new Application_Model_DbTable_Admin();
                $verifConnect->proSto($nom_utilisateur, $mot_de_passe, $role);

                $auth = Zend_Auth::getInstance();
                $result = $auth->authenticate($authAdapter);

                if ($result->isValid()) {
                    $identity = $authAdapter->getResultRowObject();

                    $authStorage = $auth->getStorage();
                    $authStorage->write($identity);

                    $this->_redirect('membres/index');
                } else {
                    $this->view->errorMessage = '<p style="font-family: helvetica;font-size: 16px;font-weight: bold;color: red;">Nom utilisateur ou mot de passe incorrect</p>';
                }
            }
        }
        $this->view->formusers = $formusers;
        //On affiche le nb d'article dans le panier
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

    //Fonction de définition de table et colonnes de login / mdp
    private function getAuthAdapter() {
        $authAdapter = new Zend_Auth_Adapter_DbTable(Zend_Db_Table::getDefaultAdapter());
        $authAdapter->setTableName('utilisateur')
                ->setIdentityColumn('nom_utilisateur')
                ->setCredentialColumn('mot_de_passe');

        return $authAdapter;
    }

    //Fonction de définition de table et colonnes de login / mdp
    private function getAuthAdapterAdmin() {
        $authAdapter = new Zend_Auth_Adapter_DbTable(Zend_Db_Table::getDefaultAdapter());
        $authAdapter->setTableName('admin')
                ->setIdentityColumn('nom_utilisateur')
                ->setCredentialColumn('mot_de_passe');

        return $authAdapter;
    }

    //Fonction de déconnexion
    public function deconnexionAction() {
        Zend_Auth::getInstance()->clearIdentity();
        $this->_helper->redirector('vider', 'panier');
    }

}
