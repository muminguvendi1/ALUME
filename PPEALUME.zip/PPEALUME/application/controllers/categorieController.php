<?php

class categorieController extends Zend_Controller_Action {

    public function init() {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            
        } else
            $this->_helper->redirector('connexion', 'authentication');
    }

    public function indexAction() {
        //Affichage des categories de produit
        $categorie = new Application_Model_DbTable_Categorie();
        $this->view->lstPdt = $categorie->selectAllCategorie();

        $categorie = new Application_Model_DbTable_Categorie();
        $this->view->lstDesactive = $categorie->selectAllDesactive();
    }

    public function activerAction() {
        $id_categorie = $this->_getParam('id_categorie', 0);

        $categorie = new Application_Model_DbTable_Categorie();
        $categorie->activerCategorie($id_categorie);
        //rédirection vers une action de controleur courant
        $this->_helper->redirector('index');
    }

    public function ajouterAction() {
        //Instanciation de form
        $form = new Application_Form_Categorie();
        $form->ajouter->setLabel('Ajouter');
        //afficher form
        $this->view->form = $form;

        /* si isPost() de l'objet de requete envoie true, alors le formulaire a été envoyé.
         * récupération des données de la raquete avec la methode getpost() dans $formData
         * véfification de leurs validité avec la méthode membre isValid() */

        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                //Si le form est valide, on recupere la valeur
                $description_categorie = $form->getValue('description_categorie');

                $categorie = new Application_Model_DbTable_Categorie();
                // l'insertion des données par la méthode ajouterFamille
                $categorie->ajouterFamille($description_categorie);
                //rédirection vers une action de controleur courant
                $this->_helper->redirector('index');
            } else {
                /* si l'une des données de formulaire n'est pas valide le controleur retourne
                 * la meme vue, et pour ne pas perdre les données on rempli les composants avec les données 
                 * fournies
                 */
                $form->populate($formData);
            }
        }
    }

    public function modifierAction() {
        //Recup des param envoyé par URL
        $id_categorie = $this->_getParam('id_categorie', 0);
        //Formulaire
        $form = new Application_Form_Categorie();
        $form->ajouter->setLabel('Modifier');
        $this->view->form = $form;

        //Si le formulaire est envoyé, et que les valeurs sont valides, on recupere les valeurs dans les variables.
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $description_categorie = $form->getValue('description_categorie');
                //Traitement des données par la fonction modifierFamille
                $categorieproduit = new Application_Model_DbTable_Categorie();
                $categorieproduit->modifierFamille($id_categorie, $description_categorie);
                //Redirection vers l'index
                $this->_helper->redirector('index');
            } else {
                /* si l'une des données de formulaire n'est pas valide le controleur retourne
                 * la meme vue, et pour ne pas perdre les données on rempli les composants avec les données 
                 * fournies
                 */
                $form->populate($formData);
            }
        } else {
            /* Si l'id existe et sa valeur est supérieure a la valeur d'initialisation, on le 
             * recupere et on rempli les champs des formulaires par les données recup
             * par la methode populate(array)
             */
            if ($id_categorie > 0) {
                $categorieproduit = new Application_Model_DbTable_Categorie();
                $pdt = $categorieproduit->rechercherFamille($id_categorie);
                //selection de la famille de produit
                $form->populate($pdt);
            }
        }
    }

    public function desactiverAction() {
        //Recup des param URL
        $id_categorie = $this->_getParam('id_categorie', 0);
        //Form
        $form = new Application_Form_SupprimerCategorie();
        $this->view->form = $form;

        //Si le formulaire est envoyé, on execute le traitement
        if ($this->getRequest()->isPost()) {
            $produit = new Application_Model_DbTable_Categorie();
            $produit->desactiverFamille($id_categorie);
            //Redirection vers l'index
            $this->_helper->redirector('index');
        } else {
            if ($id_categorie > 0) {
                $produit = new Application_Model_DbTable_Categorie();
                $pdt = $produit->rechercherFamille($id_categorie);
                $form->id_categorie->setValue($pdt['id_categorie']);
                $form->id_categorie->setAttrib('disable', $produit->fetchAll());
                $form->populate($pdt);
            }
        }
    }

}
