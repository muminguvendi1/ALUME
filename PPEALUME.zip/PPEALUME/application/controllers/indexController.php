<?php

class indexController extends Zend_Controller_Action {

    protected $cacheHandler = null;

    //On récupere le contenu du cache
    public function init() {
        $this->cacheHandler = new Application_Model_CacheHandler();
    }

    public function indexAction() {
        //On affiche le nb d'article dans le panier
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

}
