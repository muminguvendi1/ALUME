<?php

class fenetreController extends Zend_Controller_Action {

    protected $cacheHandler = null;

    //On récupere le contenu du cache
    public function init() {
        $this->cacheHandler = new Application_Model_CacheHandler();
    }

    public function indexAction() {
        //On affiche les produits dont la catégorie est 1 (Fenetres)
        $fenetre = new Application_Model_DbTable_Produit();
        $this->view->produit = $fenetre->produit(1);
        //On affiche le nb d'article dans le panier
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

    public function ficheAction() {
        //Récup du param URL et affichage de la fiche
        $id_produit = $this->_getParam('id_produit', 0);
        $fiche = new Application_Model_DbTable_Produit();
        $this->view->ficheProduit = $fiche->ficheProduit($id_produit);
        //On affiche le nb d'article dans le panier
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

}
