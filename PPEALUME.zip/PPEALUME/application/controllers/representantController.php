<?php

class representantController extends Zend_Controller_Action {

    public function init() {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            
        } else
            $this->_helper->redirector('connexion', 'authentication');
    }

    public function indexAction() {
        //On affiche la liste des representants
        $representant = new Application_Model_DbTable_Representant();
        $this->view->lstPdt = $representant->listeRepresentants();
    }

    public function ajouterAction() {
        //Instanciation de form
        $form = new Application_Form_Representant();
        $form->ajouter->setLabel('Ajouter un representant');
        //afficher form
        $this->view->form = $form;

        /* si isPost() de l'objet de requete envoie true, alors le formulaire a été envoyé.
         * récupération des données de la raquete avec la methode getpost() dans $formData
         * véfification de leurs validité avec la méthode membre isValid() */
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $nom_utilisateur = $form->getValue('nom_utilisateur');
                $mot_de_passe = $form->getValue('mot_de_passe');
                $nom = $form->getValue('nom');
                $prenom = $form->getValue('prenom');
                $date_naissance = $form->getValue('date_naissance');
                $sexe = $form->getValue('sexe');
                $date_arrivee = $form->getValue('date_arrivee');
                $salaire = $form->getValue('salaire');
                $adresse = $form->getValue('adresse');
                $ville = $form->getValue('ville');
                $code_postal = $form->getValue('code_postal');
                $email = $form->getValue('email');
                $tel = $form->getValue('tel');
                $role = 'representant';

                //Apres avoir récup les params, on les envoie pour traitement
                $ajouterUtilisateur = new Application_Model_DbTable_Utilisateur();
                $ajouterUtilisateur->ajouter($nom_utilisateur, $mot_de_passe, $nom, $prenom, $adresse, $ville, $code_postal, $tel, $email, $role);

                $ajouterRepresentant = new Application_Model_DbTable_Representant();
                $ajouterRepresentant->ajouterRepresentant($date_naissance, $sexe, $date_arrivee, $salaire);
                //Redirection a l'index
                $this->_helper->redirector('index');
            } else {
                /* si l'une des données de formulaire n'est pas valide le controleur retourne
                 * la meme vue, et pour ne pas perdre les données on rempli les composants avec les données 
                 * fournies
                 */
                $form->populate($formData);
            }
        }
    }

    public function modifierAction() {

        //Récup du param passé par URL
        $id_utilisateur = $this->_getParam('id_utilisateur', 0);
        //Formulaire
        $form = new Application_Form_Representant();
        $form->ajouter->setLabel('Modifier le representant');
        $this->view->form = $form;

        /* si isPost() de l'objet de requete envoie true, alors le formulaire a été envoyé.
         * récupération des données de la raquete avec la methode getpost() dans $formData
         * véfification de leurs validité avec la méthode membre isValid() */
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $nom_utilisateur = $form->getValue('nom_utilisateur');
                $mot_de_passe = $form->getValue('mot_de_passe');
                $nom = $form->getValue('nom');
                $prenom = $form->getValue('prenom');
                $date_naissance = $form->getValue('date_naissance');
                $sexe = $form->getValue('sexe');
                $date_arrivee = $form->getValue('date_arrivee');
                $salaire = $form->getValue('salaire');
                $adresse = $form->getValue('adresse');
                $ville = $form->getValue('ville');
                $code_postal = $form->getValue('code_postal');
                $email = $form->getValue('email');
                $tel = $form->getValue('tel');

                //Récup des valeurs dans les variables et envoi pour traitements
                $modifierUtilisateur = new Application_Model_DbTable_Utilisateur();
                $modifierUtilisateur->majProfil($nom_utilisateur, $mot_de_passe, $nom, $prenom, $adresse, $ville, $code_postal, $email, $tel, $id_utilisateur);

                $modifierRepresentant = new Application_Model_DbTable_Representant();
                $modifierRepresentant->modifierRepresentant($id_utilisateur, $date_naissance, $sexe, $date_arrivee, $salaire);
                $this->_helper->redirector('index');
            } else {
                $form->populate($formData);
            }
        } else {
            /* Si l'id existe et sa valeur est supérieure a la valeur d'initialisation, on le 
             * recupere et on rempli les champs des formulaires par les données recup
             * par la methode populate(array)
             */
            if ($id_utilisateur > 0) {
                $representant = new Application_Model_DbTable_Representant();
                $pdt = $representant->rechercheRepresentant($id_utilisateur);

                $representants = new Application_Model_DbTable_Utilisateur();
                $pdts = $representants->rechercherClient($id_utilisateur);
                //On recupere les données pour remplir le form
                $form->populate($pdt);
                $form->populate($pdts);
            }
        }
    }

    public function supprimerAction() {

        //Récup du param envoyé par URL
        $id_utilisateur = $this->_getParam('id_utilisateur', 0);
        //Formulaire
        $form = new Application_Form_SupprimerRepresentant();
        $this->view->form = $form;

        //Si le formulaire est validé, on execute les fonctions
        if ($this->getRequest()->isPost()) {
            $supprimerUtilisateur = new Application_Model_DbTable_Utilisateur();
            $supprimerUtilisateur->supprimerRepresentant($id_utilisateur);

            $supprimerRepresentant = new Application_Model_DbTable_Representant();
            $supprimerRepresentant->supprimerRepresentant($id_utilisateur);
            $this->_helper->redirector('index');
        } else {
            if ($id_utilisateur > 0) {
                //Sinon on récupere les valeurs pour les afficher dans le formulaire
                $representant = new Application_Model_DbTable_Representant();
                $pdt = $representant->rechercheRepresentant($id_utilisateur);

                $representants = new Application_Model_DbTable_Utilisateur();
                $pdts = $representants->rechercherClient($id_utilisateur);
                //On recupere les données pour remplir le form
                $form->populate($pdt);
                $form->populate($pdts);
            }
        }
    }

}
