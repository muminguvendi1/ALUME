<?php

class produitController extends Zend_Controller_Action {

    //La fonction init est éxécute dans tout les cas, si on n'est pas connecté il faut se connecter.
    //Pas de controle admin/user car les ACL le font déja.
    public function init() {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            
        } else
            $this->_helper->redirector('connexion', 'authentication');
    }

    public function indexAction() {
        $produits = new Application_Model_DbTable_Produit();
        $this->view->lstPdt = $produits->selectAllProduit();
    }

    public function ajouterAction() {
        //Instanciation de form
        $form = new Application_Form_Produit();
        $form->ajouter->setLabel('Ajouter un produit');
        //afficher form
        $this->view->form = $form;

        /* si isPost() de l'objet de requete envoie true, alors le formulaire a été envoyé.
         * récupération des données de la raquete avec la methode getpost() dans $formData
         * véfification de leurs validité avec la méthode membre isValid() */

        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                //récupération des données des elements du form
                $photo_produit = $form->getValue('photo_produit');
                $designation_produit = $form->getValue('designation_produit');
                $prix_produit = $form->getValue('prix_produit');
                $description_produit = $form->getValue('description_produit');
                $quantite_stock = $form->getValue('quantite_stock');
                $id_categorie = $form->getValue('id_categorie');
                $id_fournisseur = $form->getValue('id_fournisseur');
                //l'instanciation des données par la méthode ajouterProduit()
                $produit = new Application_Model_DbTable_Produit();
                // l'insertion des données par la méthode ajouterProduit()
                $produit->ajouterProduit($photo_produit, $designation_produit, $prix_produit, $description_produit, $quantite_stock, $id_categorie, $id_fournisseur);
                //rédirection vers une action de controleur courant
                $this->_helper->redirector('index');
            } else {
                /* si l'une des données de formulaire n'est pas valide le controleur retourne
                 * la meme vue, et pour ne pas perdre les données on rempli les composants avec les données 
                 * fournies
                 */
                $form->populate($formData);
            }
        }
    }

    public function modifierAction() {
        //Récup des params URL
        $id_produit = $this->_getParam('id_produit', 0);
        //Form
        $form = new Application_Form_Produit();
        $form->ajouter->setLabel('Modifier le produit');
        $this->view->form = $form;
        //vérification si form envoyé + valeur valides
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $photo_produit = $form->getValue('photo_produit');
                $designation_produit = $form->getValue('designation_produit');
                $prix_produit = $form->getValue('prix_produit');
                $description_produit = $form->getValue('description_produit');
                $id_categorie = $form->getValue('id_categorie');
                $quantite_stock = $form->getValue('quantite_stock');
                $id_fournisseur = $form->getValue('id_fournisseur');

                //Envoi des parametres dans la table
                $produit = new Application_Model_DbTable_Produit();
                $produit->modifierProduit($photo_produit, $id_produit, $designation_produit, $prix_produit, $description_produit, $quantite_stock, $id_categorie, $id_fournisseur);

                //Redirection vers l'index
                $this->_helper->redirector('index');
            } else {
                //Si les valeurs ne sont pas valides, on réaffiche le form avec ce qui est valide.
                $form->populate($formData);
            }
        } else {
            /* Si l'id existe et sa valeur est supérieure a la valeur d'initialisation, on le 
             * recupere et on rempli les champs des formulaires par les données recup
             * par la methode populate(array)
             */
            if ($id_produit > 0) {
                $produit = new Application_Model_DbTable_Produit();
                $pdt = $produit->obtenirProduit($id_produit);

                $form->populate($pdt);
            }
        }
    }

    public function stockerAction() {
        //Récup des param URL
        $id_produit = $this->_getParam('id_produit', 0);
        // On affiche dans la vue le resultat retourné par la fonction listeProduitStock
        $produit = new Application_Model_DbTable_Produit();
        $this->view->lstStockPdt = $produit->listeProduitStock($id_produit);

        //Ajout du formulaire
        $form = new Application_Form_Stock();
        $this->view->form = $form;
        //vérification si form envoyé + valeur valides
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                //récupération des données des éléments du form
                $date_stock = $form->getValue('date_stock');
                $quantite_stock = $form->getValue('quantite_stock');
                $id_fournisseur = $form->getValue('id_fournisseur');
                //Instanciation de model stock
                $stock = new Application_Model_DbTable_Approvision();
                $stock->ajouterStock($date_stock, $quantite_stock, $id_fournisseur, $id_produit);
                //redirection vers une action de controleur courant
                $this->_helper->redirector('index');
            } else {
                $form->populate($formData);
            }
        }
    }

    public function desactiverAction() {
        $form = new Application_Form_Supprimer();
        $form->ajouter->setLabel('Desactiver');
        $this->view->form = $form;
        // Récupération de parametre id qui spécifie l'id de produit, et on l'initialise a 0 si vide
        $id_produit = $this->_getParam('id_produit', 0);
        if ($this->getRequest()->isPost()) {
            //On supprime le produit qui possede l'id
            $produit = new Application_Model_DbTable_Produit();
            $produit->desactiverProduit($id_produit);
            $this->_helper->redirector('index');
        } else {
            if ($id_produit > 0) {
                $produit = new Application_Model_DbTable_Produit();
                $pdt = $produit->obtenirProduit($id_produit);
                $form->id_categorie->setValue($pdt['id_categorie']);
                $form->id_categorie->setAttrib('disable', $produit->fetchAll());
                $form->populate($pdt);
            }
        }
    }

}
