<?php

class commandeController extends Zend_Controller_Action {

    protected $cacheHandler = null;

    //La fonction init est éxécute dans tout les cas, si on n'est pas connecté il faut se connecter.
    //Pas de controle admin/user car les ACL le font déja.
    public function init() {
        $auth = Zend_Auth::getInstance();
        if ($auth->hasIdentity()) {
            
        } else
            $this->_helper->redirector('connexion', 'authentication');
        //Récupération des articles du cache
        $this->cacheHandler = new Application_Model_CacheHandler();
    }

    //Affichage de toutes les commandes
    public function indexAction() {
        $commandes = new Application_Model_DbTable_Commande();
        $this->view->listeCommandes = $commandes->fetchAll();
    }

    //Récup de l'id_commande envoyé via URL et appel de fonction avec le param
    public function modifierAction() {
        $id_commande = $this->_getParam('id_commande', 0);
        $modifier = new Application_Model_DbTable_Commande();
        $this->view->detailsCommande = $modifier->gestionCommandes($id_commande);
    }

    public function supprimerAction() {
        //Form supprimer
        $form = new Application_Form_SupprimerCommande();
        $this->view->form = $form;
        //Récup param id_commande envoyé par URL
        $id_commande = $this->_getParam('id_commande', 0);
        if ($this->getRequest()->isPost()) {
            //Si le fomulaire est envoyé, suppression des lignes...
            $ligneCommande = new Application_Model_DbTable_Lignecommande();
            $ligneCommande->supprimerCommande($id_commande);

            $ligneFacture = new Application_Model_DbTable_Lignefacture();
            $ligneFacture->supprimerCommande($id_commande);

            $commande = new Application_Model_DbTable_Commande();
            $commande->supprimerCommande($id_commande);

            $facture = new Application_Model_DbTable_Facture();
            $facture->supprimerCommande($id_commande);
            //Apres traitement, renvoi vers l'index
            $this->_helper->redirector('index');
        } else {
            if ($id_commande > 0) {
                //On remplit le formulaire avec les valeurs de la commande avant affichage
                $commande = new Application_Model_DbTable_Commande();
                $c = $commande->obtenirCommande($id_commande);

                $form->populate($c);
            }
        }
    }

    public function ligneAction() {
        //Récup des params envoyé par URL
        $id_ligne = $this->_getParam('id_ligne', 0);
        $id_commande = $this->_getParam('id_commande', 0);
        //Formulaire -> vue
        $form = new Application_Form_ModifierLigneCommande();
        $this->view->form = $form;
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                //Si formulaire envoyé et valeurs valides, on récupere les valeurs
                $date_liv_souhaite = $form->getValue('date_liv_souhaite');
                $adresse_livraison = $form->getValue('adresse_livraison');
                $ville_livraison = $form->getValue('ville_livraison');
                $cp_livraison = $form->getValue('cp_livraison');
                $adresse_facturation = $form->getValue('adresse_facturation');
                $ville_facturation = $form->getValue('ville_facturation');
                $cp_facturation = $form->getValue('cp_facturation');
                $qte = $form->getValue('quantite_commande');
                //Traitement des données...
                $commande = new Application_Model_DbTable_Commande();
                $commande->updateCommande($date_liv_souhaite, $id_commande);

                $facture = new Application_Model_DbTable_Facture();
                $facture->updateFacture($adresse_livraison, $ville_livraison, $cp_livraison, $adresse_facturation, $ville_facturation, $cp_facturation, $id_commande);

                $produit = new Application_Model_DbTable_Lignecommande();
                $produit->updateLignecommande($qte, $id_ligne);
                //Redirection vers l'index
                $this->_helper->redirector('index');
            } else {
                // Sinon on reaffiche le fom avec les valeurs correctes
                $form->populate($formData);
            }
        } else {
            /* Si l'id existe et sa valeur est supérieure a la valeur d'initialisation, on le 
             * recupere et on rempli les champs des formulaires par les données recup
             * par la methode populate(array)
             */
            if ($id_ligne > 0) {
                $ligneCommande = new Application_Model_DbTable_Lignecommande();
                $lc = $ligneCommande->obtenirLigne($id_ligne);

                $commande = new Application_Model_DbTable_Commande();
                $c = $commande->obtenirCommande($id_commande);

                $facture = new Application_Model_DbTable_Facture();
                $f = $facture->obtenirLigne($id_commande);
                //selection de la famille de produit
                $form->populate($lc);
                $form->populate($c);
                $form->populate($f);
            }
        }
    }

    public function supprimerLigneAction() {
        $form = new Application_Form_SupprimerLigneCommande();
        $this->view->form = $form;
        // Récupération de parametre id qui spécifie l'id de produit, et on l'initialise a 0 si vide
        $id_ligne = $this->_getParam('id_ligne', 0);
        $id_commande = $this->_getParam('id_commande', 0);
        if ($this->getRequest()->isPost()) {
            //Si formulaire envoyé, traitement des données
            $nblignes = new Application_Model_DbTable_Lignecommande();
            $count = $nblignes->nbLigne($id_commande);
            //si le nb de ligne est égal a 1, on supprime la commande et la facture aussi
            if ($count == 1) {
                $ligneCommande = new Application_Model_DbTable_Lignecommande();
                $ligneCommande->supprimerCommande($id_commande);

                $ligneFacture = new Application_Model_DbTable_Lignefacture();
                $ligneFacture->supprimerCommande($id_commande);

                $commande = new Application_Model_DbTable_Commande();
                $commande->supprimerCommande($id_commande);

                $facture = new Application_Model_DbTable_Facture();
                $facture->supprimerCommande($id_commande);
            }
            //On supprime les lignes commande et facture concernées
            $commande = new Application_Model_DbTable_Lignecommande();
            $commande->supprimerLigne($id_ligne);

            $facture = new Application_Model_DbTable_Lignefacture();
            $facture->supprimerLigne($id_ligne);
            //Redirection vers l'index
            $this->_helper->redirector('index');
        } else {
            /* Si l'id existe et sa valeur est supérieure a la valeur d'initialisation, on le 
             * recupere et on rempli les champs des formulaires par les données recup
             * par la methode populate(array)
             */
            if ($id_ligne > 0) {
                $ligneCommande = new Application_Model_DbTable_Lignecommande();
                $lc = $ligneCommande->obtenirLigne($id_ligne);

                $commande = new Application_Model_DbTable_Commande();
                $c = $commande->obtenirCommande($id_commande);

                $facture = new Application_Model_DbTable_Facture();
                $f = $facture->obtenirLigne($id_commande);
                //selection de la famille de produit
                $form->populate($lc);
                $form->populate($c);
                $form->populate($f);
            }
        }
    }

}
