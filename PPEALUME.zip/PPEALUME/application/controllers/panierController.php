<?php

class panierController extends Zend_Controller_Action {

    protected $_redirector = null;
    protected $cacheHandler = null;
    protected $dbAdapter = null;
    protected $productsGetter = null;

    //Renvoi vers page de connexion si l'utilisateur n'est pas connecté, sinon instanciation
    public function init() {
        $this->_redirector = new Application_Model_Redirector($this->_helper->getHelper('Redirector'));
        $this->cacheHandler = new Application_Model_CacheHandler();
        $this->dbAdapter = $this->getInvokeArg('bootstrap')->getPluginResource('db')->getDbAdapter();
        $this->productsGetter = new Application_Model_ProductsGetter($this->dbAdapter);
    }

    public function indexAction() {
        $auth = Zend_Auth::getInstance();
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('connexion', 'authentication');
        }

        //On recupere le contenu du cache dans la variable cartitems
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $amount = 0;
        //Si l'utilisateur a des elements dans son panier, on récupere les valeurs de chaque element
        if (!empty($cartItems)) {
            foreach ($cartItems as $key => $value) {
                $productRecord = $this->productsGetter->getProducts($key);
                $cartItems[$key]['id_produit'] = $productRecord[0]['id_produit'];
                $cartItems[$key]['designation_produit'] = $productRecord[0]['designation_produit'];
                $cartItems[$key]['prixTTC'] = $productRecord[0]['prixTTC'] * $cartItems[$key]['quantity'];
                $amount = $amount + $cartItems[$key]['prixTTC'];
            }
        }
        //On affiche dans la vue le contenu
        $this->view->cartItems = $cartItems;
        $this->view->amount = $amount;
    }

    public function ajouterAction() {

        $this->_helper->layout()->disableLayout();
        if ($this->getRequest()->isPost()) {
            $itemToAdd = $this->_request->getPost('id');
            $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
            //On récupere l'id du produit ainsi que la quantité pour les ajouter dans le panier
            if ($cartItems) {
                $cartItems[$itemToAdd]['product_id'] = $itemToAdd;
                if (!empty($cartItems[$itemToAdd]['quantity'])) {
                    $cartItems[$itemToAdd]['quantity'] = $cartItems[$itemToAdd]['quantity'] + 1;
                } else {
                    $cartItems[$itemToAdd]['quantity'] = 1;
                }
            } else {
                //Si le panier est vide, on le crée puis on ajoute le produit
                $cartItems = array();
                $cartItems[$itemToAdd] = array("product_id" => $itemToAdd, 'quantity' => 1);
            }
            $this->cacheHandler->save(Application_Model_CartCache::cartID, $cartItems);
            $this->view->itemAddedOK = 1;
        }
    }

    public function supprimerAction() {
        $auth = Zend_Auth::getInstance();
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('connexion', 'authentication');
        }
        //On supprime le produit du panier qui a l'id du produit et redirection a l'index
        $this->cacheHandler->cleanCacheID($this->getRequest()->getQuery('id'));
        $this->_redirector->redirect("index", "panier");
    }

    public function viderAction() {

        //On vide le cache donc tout le panier, redirection.
        $this->cacheHandler->cleanCache();
        $this->_redirector->redirect("index", "index");
    }

    public function commanderAction() {
        $auth = Zend_Auth::getInstance();
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('connexion', 'authentication');
        }
        // On récupere l'id de l'utilisateur connecté
        $auth = Zend_Auth::getInstance();
        $identify = $auth->getStorage()->read();
        $id_utilisateur = $identify->id_utilisateur;


        //Instanciation de form
        $form = new Application_Form_Commande();
        //afficher form
        $this->view->form = $form;
        // On réaffiche le contenu du panier comme dans la fonction index
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $amount = 0;
        if (!empty($cartItems)) {
            foreach ($cartItems as $key => $value) {
                $productRecord = $this->productsGetter->getProducts($key);
                $cartItems[$key]['id_produit'] = $productRecord[0]['id_produit'];
                $cartItems[$key]['designation_produit'] = $productRecord[0]['designation_produit'];
                $cartItems[$key]['description_produit'] = $productRecord[0]['description_produit'];
                $cartItems[$key]['prixTTC'] = $productRecord[0]['prixTTC'] * $cartItems[$key]['quantity'];

                $amount = $amount + $cartItems[$key]['prixTTC'];
            }
        }

        $this->view->cartItems = $cartItems;
        $this->view->amount = $amount;



        /* si isPost() de l'objet de requete envoie true, alors le formulaire a été envoyé.
         * récupération des données de la raquete avec la methode getpost() dans $formData
         * véfification de leurs validité avec la méthode membre isValid() */
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                //récupération des données des elements du form
                $date_livraison = $form->getValue('date_liv_souhaite');
                $adresse_livraison = $form->getValue('adresse_livraison');
                $ville_livraison = $form->getValue('ville_livraison');
                $cp_livraison = $form->getValue('cp_livraison');
                $adresse_facturation = $form->getValue('adresse_facturation');
                $ville_facturation = $form->getValue('ville_facturation');
                $cp_facturation = $form->getValue('cp_facturation');

                //Envoie des parametres du formulaire dans les tables
                $commander = new Application_Model_DbTable_Commande();
                $commander->commander($id_utilisateur, $date_livraison);

                $facture = new Application_Model_DbTable_Facture();
                $facture->commander($adresse_livraison, $ville_livraison, $cp_livraison, $adresse_facturation, $ville_facturation, $cp_facturation);

                $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
                $amount = 0;
                foreach ($cartItems as $key => $value) {
                    $productRecord = $this->productsGetter->getProducts($key);
                    $cartItems[$key]['id_produit'] = $productRecord[0]['id_produit'];
                    $id = $cartItems[$key]['id_produit'];
                    $lignefacture = new Application_Model_DbTable_Lignefacture();
                    $lignefacture->commander($id);
                }
                foreach ($cartItems as $key => $value) {
                    $productRecord = $this->productsGetter->getProducts($key);
                    $cartItems[$key]['id_produit'] = $productRecord[0]['id_produit'];
                    $id = $cartItems[$key]['id_produit'];
                    $qte = $cartItems[$key]['quantity'];
                    $lignefacture = new Application_Model_DbTable_Lignecommande();
                    $lignefacture->commander($id, $qte);
                }

                //rédirection vers une action de controleur
                $this->_helper->redirector('index', 'membres');
            } else {
                /* si l'une des données de formulaire n'est pas valide le controleur retourne
                 * la meme vue, et pour ne pas perdre les données on rempli les composants avec les données 
                 * fournies
                 */
                $form->populate($formData);
            }
        }
    }

    public function etatAction() {
        $auth = Zend_Auth::getInstance();
        if (!$auth->hasIdentity()) {
            $this->_helper->redirector('connexion', 'authentication');
        }
        $this->_helper->layout()->disableLayout();
        $cartItems = $this->cacheHandler->getCacheId(Application_Model_CartCache::cartID);
        $this->view->cartItems = $cartItems;
    }

}
