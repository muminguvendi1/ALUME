<?php


class indexController extends Zend_Controller_Action {

    public function indexAction() {
        
    }

}
